<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use ZipArchive;
use Illuminate\Support\Facades\Storage;
use App\Models\Product;

class InvoiceController extends Controller
{
    //
    public function index(Request $request)
    {
        $data = Product::get();
        return view('index', compact('data'));
    }

    public function exportPDFC(Request $request)
    {
        // Get the selected product IDs from the request

        $productIds = $request->input('product_ids');

        // echo "<pre>";
        // print_R($request->All());
        // exit;

        if (!$productIds) {
            return response()->json(['error' => 'No products selected'], 400);
        }

        // Fetch the products from the database using the selected IDs
        $products = Product::whereIn('id', $productIds)->get();

        $data['products'] = $products;
        $pdf = Pdf::loadView('inv', $data);
        // return $pdf->stream();
        //return $pdf->stream('invoice.pdf');
        return $pdf->download('inv.pdf');

        // Prepare data for the PDF
        // $data = [];
        // foreach ($products as $product) {
        //     $data[] = [
        //         'product_name' => $product->product_name, // Adjust as necessary
        //         'quantity' => $product->quantity, // Adjust as necessary
        //         'mas_price' => '$' . number_format($product->mas_price, 2) // Adjust as necessary
        //     ];
        // }

        // $pdf = Pdf::loadView('invoice', ['data' => $data]);
        // return $pdf->download('invoice.pdf');
    }

    public function exportPDFGM(Request $request)
{
    // Example data for the invoice (you can fetch this from the database)
    $data = [
        [
            'quantity' => 2,
            'description' => 'Gold',
            'price' => '$500.00'
        ],
        [
            'quantity' => 3,
            'description' => 'Silver',
            'price' => '$300.00'
        ],
        [
            'quantity' => 5,
            'description' => 'Platinum',
            'price' => '$200.00'
        ]
    ];

    // Generate the PDF for the invoice
    $pdf = Pdf::loadView('in', ['data' => $data]);

    // Save the PDF to storage
    $pdfPath = storage_path('app/public/invoice.pdf');
    $pdf->save($pdfPath);

    // WhatsApp phone number (replace with the recipient's phone number)
    $phoneNumber = '1234567890';  // Replace with the actual phone number
    $message = 'Hi, here\'s the invoice! Please find the attached PDF.';  // Customize the message

    // Generate the WhatsApp Web URL with a pre-filled message
    $whatsappUrl = "https://web.whatsapp.com/send?phone=$phoneNumber&text=" . urlencode($message);

    // Debugging line to check if $whatsappUrl is being set correctly
    dd($whatsappUrl);  // This will stop execution and display the value of $whatsappUrl

    // Pass the data to the view, including the $whatsappUrl and the path to the PDF
    return view('in', [
        'whatsappUrl' => $whatsappUrl, 
        'pdfPath' => asset('storage/invoice.pdf'),
        'data' => $data
    ]);
}
public function exportPDFG(Request $request)
{
    // Example data, you could fetch from the database if needed
    $data = [
        [
            'quantity' => 2,
            'description' => 'Gold',
            'price' => '$500.00'
        ],
        [
            'quantity' => 3,
            'description' => 'Silver',
            'price' => '$300.00'
        ],
        [
            'quantity' => 5,
            'description' => 'Platinum',
            'price' => '$200.00'
        ]
    ];

    // WhatsApp link
    $phoneNumber = '9481926073';  // Replace with the recipient's phone number
    $message = 'Hi, here\'s the invoice!';  // Replace with your desired message
    $whatsappUrl = "https://web.whatsapp.com/send?phone=$phoneNumber&text=" . urlencode($message);

    // Load the view for the invoice
    $pdf = Pdf::loadView('in', ['data' => $data, 'whatsappUrl' => $whatsappUrl]);

    // Return the PDF for inline viewing (in the browser or popup)
    return $pdf->stream('invoice.pdf');
}



    public function exportPDFG1(Request $request)
    {
        // Example data, you could fetch from the database if needed
        $data = [
            [
                'quantity' => 2,
                'description' => 'Gold',
                'price' => '$500.00'
            ],
            [
                'quantity' => 3,
                'description' => 'Silver',
                'price' => '$300.00'
            ],
            [
                'quantity' => 5,
                'description' => 'Platinum',
                'price' => '$200.00'
            ]
        ];

        // Load the view for the invoice
        $pdf = Pdf::loadView('in', ['data' => $data]);

        // Return the PDF for download with a specific filename
        //return $pdf->download('invoice.pdf');
        return $pdf->stream('invoice.pdf');
    }

    public function indexM(Request $request)
    {
        // Data to be included in the PDF
        $data = [
            [
                'quantity' => 2,
                'description' => 'Gold',
                'price' => '$500.00'
            ],
            [
                'quantity' => 3,
                'description' => 'Silver',
                'price' => '$300.00'
            ],
            [
                'quantity' => 5,
                'description' => 'Platinum',
                'price' => '$200.00'
            ]
        ];

        // Load the PDF view and generate the PDF as string
        $pdf = Pdf::loadView('invoice', ['data' => $data]);
        $pdfContent = $pdf->output();

        // Create a temporary file for the zip archive
        $zipFilePath = tempnam(sys_get_temp_dir(), 'invoices') . '.zip';
        $zip = new ZipArchive;

        if ($zip->open($zipFilePath, ZipArchive::CREATE) === TRUE) {
            // Add the PDF content to the zip file in memory
            $zip->addFromString('invoice.pdf', $pdfContent);
            $zip->close();
        }

        // Return the zip file as a download response
        return response()->download($zipFilePath, 'invoices.zip')->deleteFileAfterSend(true);
    }

    public function storeDb()
    {
        exit("helllo");
    }
}

//     public function index1(Request $request)
//     {
//         $data = [
//             [
//                 'quantity' => 2,
//                 'description' => 'Gold',
//                 'price' => '$500.00'
//             ],
//             [
//                 'quantity' => 3,
//                 'description' => 'Silver',
//                 'price' => '$300.00'
//             ],
//             [
//                 'quantity' => 5,
//                 'description' => 'Platinum',
//                 'price' => '$200.00'
//             ]
//         ];

//         $pdf = Pdf::loadView('invoice', ['data' => $data]);

//         // Define file paths
//         $pdfFilePath = storage_path('app/public/invoice.pdf');
//         $zipFilePath = storage_path('app/public/invoices.zip');

//         // Store the generated PDF in the file system
//         Storage::put('public/invoice.pdf', $pdf->output());

//         // Create a zip archive
//         $zip = new ZipArchive;
//         if ($zip->open($zipFilePath, ZipArchive::CREATE) === TRUE) {
//             // Add the PDF file to the zip archive
//             $zip->addFile($pdfFilePath, 'invoice.pdf');
//             $zip->close();
//         }

//         // Return the zip file as a download response
//         return response()->download($zipFilePath)->deleteFileAfterSend(true);
       
//        // $pdf = Pdf::loadView('invoice', ['data' => $data]);
       
//         //return $pdf->download();
//     }
// }
