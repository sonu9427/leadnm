
public function exportPDFG(Request $request)
{
    // Example data, you could fetch from the database if needed
    $data = [
        [
            'quantity' => 2,
            'description' => 'Gold',
            'price' => '$500.00'
        ],
        [
            'quantity' => 3,
            'description' => 'Silver',
            'price' => '$300.00'
        ],
        [
            'quantity' => 5,
            'description' => 'Platinum',
            'price' => '$200.00'
        ]
    ];

    // WhatsApp link
    $phoneNumber = '9481926073';  // Replace with the recipient's phone number
    $message = 'Hi, here\'s the invoice!';  // Replace with your desired message
    $whatsappUrl = "https://web.whatsapp.com/send?phone=$phoneNumber&text=" . urlencode($message);

    // Load the view for the invoice
    $pdf = Pdf::loadView('in', ['data' => $data, 'whatsappUrl' => $whatsappUrl]);

    // Return the PDF for inline viewing (in the browser or popup)
    return $pdf->stream('invoice.pdf');
}

how to set below code send invoice.pdf file with whattup massage
 $pdfPath = storage_path('app/public/invoice.pdf');
    $pdf->save($pdfPath);


    201 - CREATED - The request was successful. We created a new resource and the response body contains the representation.
{
  "account_sid": "AC2161da2be3627e1f987a3730b86f9051",
  "api_version": "2010-04-01",
  "body": "Your appointment is coming up on 12/1 at 3pm",
  "date_created": "Tue, 17 Dec 2024 18:37:24 +0000",
  "date_sent": null,
  "date_updated": "Tue, 17 Dec 2024 18:37:24 +0000",
  "direction": "outbound-api",
  "error_code": null,
  "error_message": null,
  "from": "whatsapp:+14155238886",
  "messaging_service_sid": null,
  "num_media": "0",
  "num_segments": "1",
  "price": null,
  "price_unit": null,
  "sid": "MMa346865803b87b78057527ac4b70a30d",
  "status": "queued",
  "subresource_uris": {
    "media": "/2010-04-01/Accounts/AC2161da2be3627e1f987a3730b86f9051/Messages/MMa346865803b87b78057527ac4b70a30d/Media.json"
  },
  "to": "whatsapp:+919481926073",
  "uri": "/2010-04-01/Accounts/AC2161da2be3627e1f987a3730b86f9051/Messages/MMa346865803b87b78057527ac4b70a30d.json"
}



<?php
    // Update the path below to your autoload.php,
    // see https://getcomposer.org/doc/01-basic-usage.md
    require_once '/path/to/vendor/autoload.php';
    use Twilio\Rest\Client;

    $sid    = "AC2161da2be3627e1f987a3730b86f9051";
    $token  = "[AuthToken]";
    $twilio = new Client($sid, $token);

    $message = $twilio->messages
      ->create("whatsapp:+919481926073", // to
        array(
          "from" => "whatsapp:+14155238886",
          "contentSid" => "HXb5b62575e6e4ff6129ad7c8efe1f983e",
          "contentVariables" => "{"1":"12/1","2":"3pm"}",
          "body" => "Your Message"
        )
      );

print($message->sid);


use Twilio\Rest\Client;

public function sendInvoiceViaWhatsapp(Request $request)
{
    // Generate and save the PDF
    $data = [
        ['quantity' => 2, 'description' => 'Gold', 'price' => '$500.00'],
        ['quantity' => 3, 'description' => 'Silver', 'price' => '$300.00'],
        ['quantity' => 5, 'description' => 'Platinum', 'price' => '$200.00'],
    ];
    
    $pdf = Pdf::loadView('in', ['data' => $data]);
    $pdfPath = storage_path('app/public/invoice.pdf');
    $pdf->save($pdfPath);
    
    // WhatsApp details
    $phoneNumber = '8320448196'; // Recipient's phone number
    $message = 'Hi, here\'s the invoice!'; // The message text
    
    // Twilio credentials
    $sid = 'your_twilio_sid';
    $authToken = 'your_twilio_auth_token';
    $twilio = new Client($sid, $authToken);

    // Send the message with the PDF attachment
    try {
        $twilio->messages->create(
            "whatsapp:$phoneNumber",  // Send message to the WhatsApp number
            [
                'from' => 'whatsapp:+14155238886',  // Replace with your Twilio WhatsApp number
                'body' => $message,
                'mediaUrl' => [url('storage/invoice.pdf')],  // Make sure the file is publicly accessible
            ]
        );

        return response()->json(['status' => 'success', 'message' => 'Invoice sent successfully!']);
    } catch (Exception $e) {
        return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
