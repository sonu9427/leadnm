<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProjectCustomerPayment;
use App\Models\Project;
use Illuminate\Support\Facades\DB;

class ProjectCustomerPaymentController extends Controller
{

    
    public function indexq(Request $request)
    {
        if ($request->ajax()) {
            // Eager load 'project' and 'paymentStatus' relationships
            $data = ProjectCustomerPayment::with(['project', 'paymentStatus'])
                ->whereHas('paymentStatus', function ($query) {
                    $query->where('status_name', 'Refund');
                })
                ->get();  // Fetch the results as a collection
    
            // Optional: Print the result for debugging
            echo "<pre>";
            print_r($data->toArray());
            die();  // Stop further execution for debugging purposes
    
            return datatables()->of($data)->make(true);
        }
    
        return view('project');
    }


    public function index11(Request $request)
{
    if ($request->ajax()) {
        // Fetch all payments grouped by project with eager-loaded relationships
        $data = Project::with(['customerPayments.paymentStatus'])
            ->get()
            ->map(function ($project) {
                // Calculate total deposit and refund for each project
                $totalDeposit = $project->customerPayments
                    ->where('paymentStatus.status_name', 'Deposit')
                    ->sum('total_paid');

                $totalRefund = $project->customerPayments
                    ->where('paymentStatus.status_name', 'Refund')
                    ->sum('total_paid');

                // Assume the status name you want to show is based on the first payment status (optional logic)
                $statusName = $project->customerPayments->first()?->paymentStatus->status_name ?? 'N/A';

                return [
                    'project_id' => $project->id,
                    'project_name' => $project->name,
                    'total_deposit' => $totalDeposit,
                    'total_refund' => $totalRefund,
                    'status_name' => $statusName,
                ];
            });

        return datatables()->of($data)->make(true);
    }

    return view('project');
}


public function index5(Request $request)
{
    if ($request->ajax()) {
        // Aggregate total deposit and refund per project, grouped by project and status.
        $data = ProjectCustomerPayment::with(['project', 'paymentStatus'])
            ->get()
            ->groupBy('project.id') // Group by project ID

            // Transform the grouped data to calculate deposit and refund totals.
            ->map(function ($payments, $projectId) {
                $project = $payments->first()->project;

                $totalDeposit = $payments->where('paymentStatus.status_name', 'Deposit')
                    ->sum('total_paid');

                $totalRefund = $payments->where('paymentStatus.status_name', 'Refund')
                    ->sum('total_paid');

                // Retrieve the last status name (or the most relevant one)
                $statusName = $payments->last()->paymentStatus->status_name;

                return [
                    'project_id' => $project->id,
                    'project_name' => $project->name,
                    'total_deposit' => $totalDeposit,
                    'total_refund' => $totalRefund,
                    'status_name' => $statusName,
                ];
            })
            ->values(); // Reset the keys to make it a plain array.

        // Return the data in DataTables format.
        return datatables()->of($data)->make(true);
    }

    return view('project');
}

public function indexM(Request $request)
{
    if ($request->ajax()) {
        // Aggregate payments by project ID
        $data = ProjectCustomerPayment::with(['project', 'paymentStatus'])
            ->get()
            ->groupBy('project.id') // Group by project ID
            ->map(function ($payments, $projectId) {
                $project = $payments->first()->project;

                // Calculate Total Deposit and Total Refund
                $totalDeposit = $payments->where('paymentStatus.status_name', 'Deposit')->sum('total_paid');
                $totalRefund = $payments->where('paymentStatus.status_name', 'Refund')->sum('total_paid');

                // Determine the most frequent status for the project
                $statusName = $payments->groupBy('paymentStatus.status_name')
                    ->sortByDesc(fn($group) => $group->count())
                    ->keys()
                    ->first(); // Get the most frequent status

                return [
                    'project_id' => $project->id,
                    'project_name' => $project->name,
                    'total_deposit' => $totalDeposit,
                    'total_refund' => $totalRefund,
                    'status_name' => $statusName,
                ];
            })
            ->values(); // Reset keys to make it a plain array

        return datatables()->of($data)->make(true);
    }

    return view('project');
}

public function indexNow(Request $request)
{
    if ($request->ajax()) {
        // Eager load projects and their payment statuses
        $payments = ProjectCustomerPayment::with(['project', 'paymentStatus'])
            ->whereIn('status_id', function ($query) {
                $query->select('id')->from('payment_status')->whereIn('status_name', ['Deposit', 'Refund', 'Compastion']);
            })
            ->get();

        // Prepare the final data structure
        $finalData = [];

        // Separate deposits and refunds
        foreach ($payments as $payment) {
            if ($payment->paymentStatus->status_name === 'Deposit') {
                // Store the total deposit
                $finalData[$payment->project_id]['project_name'] = $payment->project->name;
                $finalData[$payment->project_id]['total_deposit'] = $payment->total_paid;
                $finalData[$payment->project_id]['refunds'] = []; // Initialize refunds array
            } elseif (in_array($payment->paymentStatus->status_name, ['Refund', 'Compastion'])) {
                // Add refund entries for corresponding project
                $finalData[$payment->project_id]['refunds'][] = [
                    'total_refund' => $payment->total_paid,
                    'status_name' => $payment->paymentStatus->status_name,
                ];
            }
        }

        // Flatten the final data structure
        $output = [];
        foreach ($finalData as $data) {
            // Add deposit row
            $output[] = [
                'project_name' => $data['project_name'],
                'total_deposit' => $data['total_deposit'],
                'total_refund' => '',
                'status_name' => '',
            ];

            // Add refund rows
            foreach ($data['refunds'] as $refund) {
                $output[] = [
                    'project_name' => $data['project_name'],
                    'total_deposit' => '',
                    'total_refund' => $refund['total_refund'],
                    'status_name' => $refund['status_name'],
                ];
            }
        }

        // Return the data for DataTables
        return datatables()->of($output)->make(true);
    }

    return view('project');
}



public function indexMMMMMMMM(Request $request)
{
    if ($request->ajax()) {
        // Step 1: Get all payments with eager loaded projects and payment statuses
        $payments = ProjectCustomerPayment::with(['project', 'paymentStatus'])
            ->whereIn('status_id', function ($query) {
                $query->select('id')->from('payment_status')->whereIn('status_name', ['Deposit', 'Refund', 'Compastion']);
            })
            ->get();

        // Step 2: Prepare the final data structure
        $finalData = [];

        // Step 3: Separate deposits and refunds
        foreach ($payments as $payment) {
            if ($payment->paymentStatus->status_name === 'Deposit') {
                // Store the total deposit
                $finalData[$payment->project_id]['project_name'] = $payment->project->name;
                $finalData[$payment->project_id]['total_deposit'] = isset($finalData[$payment->project_id]['total_deposit']) 
                    ? $finalData[$payment->project_id]['total_deposit'] + $payment->total_paid 
                    : $payment->total_paid;
            } elseif (in_array($payment->paymentStatus->status_name, ['Refund', 'Compastion'])) {
                // Add refund entries for corresponding project
                $finalData[] = [
                    'project_name' => $payment->project->name,
                    'total_deposit' => isset($finalData[$payment->project_id]['total_deposit']) 
                        ? $finalData[$payment->project_id]['total_deposit'] 
                        : 0, // No deposit for refunds
                    'total_refund' => $payment->total_paid,
                    'status_name' => $payment->paymentStatus->status_name,
                ];
            }
        }

        // Convert the associative array to a regular array
        $finalData = array_values($finalData);

        // Return the data for DataTables
        return datatables()->of($finalData)->make(true);
    }

    return view('project');
}

public function index(Request $request)
{
    if ($request->ajax()) {
        // Step 1: Get total deposits for each project
        $deposits = ProjectCustomerPayment::select(
                'projects.name as project_name',
                DB::raw('SUM(CASE WHEN payment_status.status_name = "Deposit" THEN total_paid ELSE 0 END) as total_deposit')
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->where('payment_status.status_name', 'Deposit')
            ->groupBy('projects.name') // Group by project name to avoid errors
            ->get();

        // Step 2: Get refunds without aggregation
        $refunds = ProjectCustomerPayment::select(
                'projects.name as project_name',
                'total_paid as total_refund', // Get individual refund amounts
                'payment_status.status_name'
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->whereIn('payment_status.status_name', ['Refund', 'Compastion'])
            ->get(); // Fetch results directly without grouping

        // Step 3: Combine results into the desired format
        $finalData = [];

        // Add deposits data
        foreach ($deposits as $deposit) {
            // Find corresponding refunds
            $correspondingRefunds = $refunds->where('project_name', $deposit->project_name);
            
            foreach ($correspondingRefunds as $refund) {
                $finalData[] = [
                    'project_name' => $deposit->project_name,
                    'total_deposit' => $deposit->total_deposit,
                    'total_refund' => $refund->total_refund,
                    'status_name' => $refund->status_name,
                ];
            }
        }

        // Return the data for DataTables
        return datatables()->of($finalData)->make(true);
    }

    return view('project');
}


public function index28(Request $request)
{
    if ($request->ajax()) {
        // Step 1: Get total deposits for each project
        $deposits = ProjectCustomerPayment::select(
                'projects.name as project_name',
                DB::raw('SUM(CASE WHEN payment_status.status_name = "Deposit" THEN total_paid ELSE 0 END) as total_deposit')
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->where('payment_status.status_name', 'Deposit')
            ->groupBy('projects.name') // Group by project name to avoid errors
            ->get();

        // Step 2: Get refunds without aggregation
        $refunds = ProjectCustomerPayment::select(
                'projects.name as project_name',
                'total_paid as total_refund', // Get individual refund amounts
                'payment_status.status_name'
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->whereIn('payment_status.status_name', ['Refund', 'Compastion'])
            ->get(); // Fetch results directly without grouping

        // Step 3: Combine results into the desired format
        $finalData = [];

        // Add deposits data
        foreach ($deposits as $deposit) {
            // Find corresponding refunds
            $correspondingRefunds = $refunds->where('project_name', $deposit->project_name);
            
            foreach ($correspondingRefunds as $refund) {
                $finalData[] = [
                    'project_name' => $deposit->project_name,
                    'total_deposit' => $deposit->total_deposit,
                    'total_refund' => $refund->total_refund,
                    'status_name' => $refund->status_name,
                ];
            }
        }

        // Return the data for DataTables
        return datatables()->of($finalData)->make(true);
    }

    return view('project');
}


public function index56(Request $request)
{
    if ($request->ajax()) {
        // Eager load 'project' and 'paymentStatus' relationships
        $data = ProjectCustomerPayment::select(
                'projects.name',
                DB::raw('SUM(CASE WHEN payment_status.status_name = "Deposit" THEN total_paid ELSE 0 END) as total_deposit'),
                DB::raw('SUM(CASE WHEN payment_status.status_name = "Refund" THEN total_paid ELSE 0 END) as total_refund'),
                'payment_status.status_name'
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->whereIn('payment_status.status_name', ['Refund', 'Compastion'])
            ->groupBy('projects.name', 'payment_status.status_name')
            ->get();  // Fetch the results as a collection

        // Optional: Print the result for debugging
        // echo "<pre>";
        // print_r($data->toArray());
        // die();  // Stop further execution for debugging purposes

        return datatables()->of($data)->make(true);
    }

    return view('project');
}

public function index133(Request $request)
{
    if ($request->ajax()) {
        // Query to aggregate total deposit and refund per project
        $data = ProjectCustomerPayment::select(
                'projects.name as project_name',
                DB::raw('SUM(CASE WHEN payment_status.status_name = "Deposit" THEN total_paid ELSE 0 END) as total_deposit'),
                DB::raw('SUM(CASE WHEN payment_status.status_name IN ("Refund", "Compastion") THEN total_paid ELSE 0 END) as total_refund'),
                'payment_status.status_name'
            )
            ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
            ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
            ->whereIn('payment_status.status_name', ['Refund', 'Compastion', 'Deposit'])
            ->groupBy('projects.name', 'payment_status.status_name')
            ->get();

            // echo "<pre>";
            // print_r($data->toArray());
            // die(); 

        // Return the result for DataTables processing
        return datatables()->of($data)->make(true);
    }

    return view('project');
}


public function indexppp(Request $request)
{
    if ($request->ajax()) {
        // Eager load 'project' and 'paymentStatus' relationships
        $data = ProjectCustomerPayment::with(['project', 'paymentStatus'])
            ->whereHas('paymentStatus', function ($query) {
                $query->whereIn('status_name', ['Refund','Compastion']);
            })
            ->get();  // Fetch the results as a collection

        // Optional: Print the result for debugging
        echo "<pre>";
        print_r($data->toArray());
        die();  // Stop further execution for debugging purposes

        return datatables()->of($data)->make(true);
    }

    return view('project');
}

public function index27(Request $request)
{
    if ($request->ajax()) {
        // Fetch all payments with project and status details
        $data = ProjectCustomerPayment::with(['project', 'paymentStatus'])->get();

        // Group payments by project ID
        $groupedData = $data->groupBy('project.id')->map(function ($payments) {
            $project = $payments->first()->project;

            // Initialize deposit and refund sums
            $totalDeposit = 0;
            $totalRefund = 0;

            // Loop through each payment to sum deposits and refunds correctly
            foreach ($payments as $payment) {
                if ($payment->paymentStatus->status_name === 'Deposit') {
                    $totalDeposit += $payment->total_paid;
                } elseif ($payment->paymentStatus->status_name === 'Refund') {
                    $totalRefund += $payment->total_paid;
                }
            }

            // Determine the final status: prioritize Deposit over Refund
            $statusName = $totalDeposit > 0 ? 'Refund' : ($totalRefund > 0 ? 'Refund' : 'Other');

            // Return the formatted project data
            return [
                'project_id' => $project->id,
                'project_name' => $project->name,
                'total_deposit' => $totalDeposit,
                'total_refund' => $totalRefund,
                'status_name' => $statusName,
            ];
        });

        // Convert the grouped data to a clean array and return via DataTables
        return datatables()->of($groupedData->values())->make(true);
    }

    // Return the view for non-AJAX requests
    return view('project');
}



    // public function index(Request $request)
    // {
    //     if ($request->ajax()) {
    //         $data = Project::with(['payments.paymentStatus']) // Load related payments and their statuses
    //             ->get()
    //             ->map(function ($project) {
    //                 $totalDeposit = $project->payments->where('paymentStatus.status_name', 'Deposit')->sum('total_paid');
    //                 $totalRefund = $project->payments->where('paymentStatus.status_name', 'Refund')->sum('total_paid');

    //                 return [
    //                     'project_id' => $project->id,
    //                     'project_name' => $project->name,
    //                     'total_deposit' => $totalDeposit,
    //                     'total_refund' => $totalRefund,
    //                 ];
    //             });

    //         return datatables()->of($data)->make(true);
    //     }

    //     return view('project');
    // }

    // public function index(Request $request)
    // {
    //     if ($request->ajax()) {
    //         $data = ProjectCustomerPayment::select(
    //             'projects.id as project_id',
    //             'projects.name as project_name',
    //             DB::raw("SUM(CASE WHEN payment_status.status_name = 'Deposit' THEN total_paid ELSE 0 END) as total_deposit"),
    //             DB::raw("SUM(CASE WHEN payment_status.status_name = 'Refund' THEN total_paid ELSE 0 END) as total_refund")
    //         )
    //         ->join('projects', 'project_customer_payments.project_id', '=', 'projects.id')
    //         ->join('payment_status', 'project_customer_payments.status_id', '=', 'payment_status.id')
    //         ->groupBy('projects.id', 'projects.name')  // Only group by project
    //         ->get();

    //         return datatables()->of($data)->make(true);
    //     }

    //     return view('project');
    // }
}
