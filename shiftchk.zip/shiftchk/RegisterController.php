<?php

namespace App\Http\Controllers\Api\Register;

use App\Http\Controllers\Controller;
use App\Models\Detail;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Shift;
use App\Models\ShiftDay;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        // Basic validation
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'email' => 'required|email|unique:users',
        //     'password' => 'required|string|min:6',
        // ]);

        $user = User::create([
            'name' => $request->name,
            'mobile' => $request->mobile,
            // 'password' => Hash::make($request->password),
        ]);

        return response()->json(['message' => 'User Registered Successfully', 'user' => $user], 201);
    }

    public function getUser(Request $request)
    {
        $users = User::get();

        $data = [];

        foreach ($users as $key => $user) {
            $data[]  = [
                'id' => $user->id,
                'name' => $user->name,
                'mobile' => $user->mobile,
                'is_checked' => $user->is_checked,
            ];
        }

        return response()->json(['message' => 'User Get Successfully', 'user' => $data], 201);
    }

    public function addUser(Request $request)
    {
        $names = ['Vimal1', 'Nihar1'];

        $existingUser = Detail::whereIn('name', $names)->pluck('name')->toArray();

        if (!empty($existingUser)) {
            $disName = implode(", ", $existingUser);
            return response()->json([
                'message' => 'Users Alredy Taken into DB',
                'user' => $disName,
            ], 404);
        }

        // Create users that don't exist
        $createdUsers = [];
        foreach ($names as $name) {
            $createdUsers[] = Detail::create([
                'name' => $name,
            ]);
        }

        return response()->json([
            'message' => 'Users stored as JSON',
            'users' => $createdUsers,
        ], 201);
    }

    public function updateChk(Request $request)
    {
        $ids = $request->input('ids');
        $isChecked = $request->input('is_checked', 'yes');

        // Split the comma-separated IDs
        $idArray = explode(',', $ids);

        // Update users with is_checked = 'yes'
        User::whereIn('id', $idArray)->update([
            'is_checked' => $isChecked
        ]);

        return response()->json([
            'message' => 'Users updated successfully',
            'updated_ids' => $idArray,
        ], 200);
    }

    public function save(Request $request)
    {
        Log::info('Shifts received:', $request->all());

        try {
            // Validate incoming data
            $validated = $request->validate([
                'shifts' => 'required|array',
                'shifts.*.shiftName' => 'required|string|max:255',
                'shifts.*.code' => 'required|string|max:50',
                'shifts.*.days' => 'required|array|min:1',
                'shifts.*.start_time' => 'required|string',
                'shifts.*.end_time' => 'required|string',
                'shifts.*.break_duration' => 'sometimes|integer|min:0',
            ]);

            Log::info('Validation passed');

            $createdShifts = [];

            // Loop through shifts and create records in both tables
            foreach ($validated['shifts'] as $shiftData) {
                // Create shift in shifts table
                $shift = Shift::create([
                    'shift_name' => $shiftData['shiftName'],
                    'code' => $shiftData['code'],
                ]);

                Log::info('Shift created:', ['id' => $shift->id, 'name' => $shift->shift_name]);

                // Create shift_days records for each selected day
                foreach ($shiftData['days'] as $day) {
                    ShiftDay::create([
                        'shift_id' => $shift->id,
                        'day' => $day,
                        'start_time' => $shiftData['start_time'],
                        'end_time' => $shiftData['end_time'],
                        'break_minutes' => $shiftData['break_duration'] ?? 0,
                    ]);
                }

                // Load the relationship to return with response
                $shift->load('days');
                $createdShifts[] = $shift;
            }

            Log::info('All shifts created successfully', ['count' => count($createdShifts)]);

            return response()->json([
                'message' => 'Shifts saved successfully',
                'shifts' => $createdShifts,
                'count' => count($createdShifts),
            ], 201);
        } catch (\Exception $e) {
            Log::error('Error saving shifts:', ['error' => $e->getMessage()]);
            return response()->json([
                'message' => 'Error saving shifts',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
