<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProjectCustomerPaymentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::get('/send-invoice/{phoneNumber}', [InvoiceController::class, 'sendInvoiceViaWhatsApp111']);


Route::get('/export-pdfg', [InvoiceController::class, 'sendInvoiceViaWhatsApp'])->name('export-pdfg');

Route::get('/', [InvoiceController::class, 'index']);

Route::get('/index1', [InvoiceController::class, 'index1']);

Route::get('/storedb', [InvoiceController::class, 'storeDb'])->name('storedb');

Route::get('/product/{id}/edit', [ProductController::class, 'edit'])->name('product.edit');

Route::put('/product/{id}', [ProductController::class, 'update'])->name('product.update');

//Route::post('/exportpdf', [InvoiceController::class, 'exportPdf'])->name('exportpdf');
//Route::get('/exportpdf', [InvoiceController::class, 'exportPDF'])->name('exportpdf');

Route::get('/exportpdf', [InvoiceController::class, 'exportPDF'])->name('exportpdf');

Route::resource('project', ProjectCustomerPaymentController::class);

Route::post('generatepdf', [ProjectCustomerPaymentController::class, 'generatePdf'])->name('generatepdf');

Route::post('/generate-multiple-pdfs', [ProjectCustomerPaymentController::class, 'generateMultiplePdfs'])->name('generate.multiple.pdfs');

Route::post('generatepdfzip', [ProjectCustomerPaymentController::class, 'generatePdfZip'])->name('generatepdfzip');






