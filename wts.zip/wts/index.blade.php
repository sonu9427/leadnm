<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="{{ public_path('invoice.css') }}" type="text/css"> 
</head>
<body>
  
<table class="table-border" align="center">
    <tr>
        <td class="width-30">
            <h2>Invoice ID: 1</h2>
        </td>
    </tr>
</table>
<div>
    <table class="product-table" border="1" align="center" width="60%">
        <thead>
            <tr>
                <th class="width-25">
                    <input type="checkbox">
                </th>
                <th class="width-25">
                    <strong>Product</strong>
                </th>
                <th class="width-50">
                    <strong>Qty</strong>
                </th>
                <th class="width-25">
                    <strong>Price</strong>
                </th>
                <th class="width-25">
                    <strong> <input type="button" name="apply" value="Apply" id="apply"></strong>
                </th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $value)
            <tr>
                <td class="width-25" align="center">
                  <input type="checkbox" name="product_id[]" id="product_id" value="{{ $value['id'] }}">
                </td>
                <td class="width-25">
                    {{ $value['name'] }}
                </td>
                <td class="width-50">
                   1
                </td>
                <td class="width-25">
                    {{ $value['price'] }}
                </td>
            </tr>
            @endforeach
        </tbody>
        {{-- <tfoot>
            <tr>
                <td class="width-70" colspan="2">
                    <strong>Sub Total:</strong>
                </td>
                <td class="width-25">
                    <strong>$1000.00</strong>
                </td>
            </tr>
            <tr>
                <td class="width-70" colspan="2">
                    <strong>Tax</strong>(10%):
                </td>
                <td class="width-25">
                    <strong>$100.00</strong>
                </td>
            </tr>
            <tr>
                <td class="width-70" colspan="2">
                    <strong>Total Amount:</strong>
                </td>
                <td class="width-25">
                    <strong>$1100.00</strong>
                </td>
            </tr>
        </tfoot> --}}
    </table>
</div>
</body>
</html>
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>

<script type="text/javascript">

$(document).ready(function(){
            $('#apply').click(function(){
                // Trigger the PDF download when the button is clicked
                //window.location.href = '{{ route("export-pdfg") }}';  // Triggering the route
                window.open('{{ route("export-pdfg") }}', 'Invoice Popup', 'width=800,height=600');
            });
        });


    $(document).on('click', '#apply11', function(e) {
        e.preventDefault();

        var selectedProducts = [];
        $('input[name="product_id[]"]:checked').each(function() {
            selectedProducts.push($(this).val());
        });

        if (selectedProducts.length > 0) {
            $.ajax({
                url: '{{ route('exportpdf') }}',
                method: 'GET',
                data: {
                product_ids: selectedProducts
                 },
                success: function(response) {
                    // Handle successful response
                    window.open(response.url, '_blank'); // Open PDF in a new tab
                },
                error: function(xhr) {
                    // Handle error response
                    alert('An error occurred: ' + xhr.statusText);
                }
            });
        } else {
            alert('Please select at least one product.');
        }
    });
</script>

{{-- <script type="text/javascript">
    $(document).on('click', '#apply', function(e) {
        e.preventDefault();
        
        var selectedProducts = [];
        $('input[name="product_id[]"]:checked').each(function() {
            selectedProducts.push($(this).val());
        });
        
        if (selectedProducts.length > 0) {
            $.ajax({
                url: '{{ route('exportpdf') }}',  // Adjust route as needed
                method: 'get',
                data: {
                    _token: '{{ csrf_token() }}',  // Add CSRF token for security
                    product_ids: selectedProducts
                },
                success: function(response) {
                    // Handle success response
                    //alert('PDF generated successfully.');
                    window.open(response.url, '_blank');
                },
                error: function(xhr) {
                    // Handle error response
                    alert('An error occurred.');
                }
            });
        } else {
            alert('Please select at least one product.');
        }
    });
</script> --}}
    