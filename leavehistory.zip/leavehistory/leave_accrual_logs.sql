-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 08, 2026 at 02:36 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `angular_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `leave_accrual_logs`
--

CREATE TABLE `leave_accrual_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `leave_type_id` bigint UNSIGNED NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_accrual_logs`
--

INSERT INTO `leave_accrual_logs` (`id`, `user_id`, `leave_type_id`, `month`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-01', '2026-01-01 10:26:29', '2026-01-28 10:26:29'),
(2, 2, 1, '2026-01', '2026-01-28 10:26:29', '2026-01-28 10:26:29'),
(3, 1, 1, '2026-02', '2026-02-01 10:26:29', '2026-01-28 10:26:29'),
(4, 1, 1, '2026-03', '2026-03-01 10:26:29', '2026-02-10 17:40:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leave_accrual_logs`
--
ALTER TABLE `leave_accrual_logs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_accrual_logs_employee_id_leave_type_id_month_unique` (`user_id`,`leave_type_id`,`month`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leave_accrual_logs`
--
ALTER TABLE `leave_accrual_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
