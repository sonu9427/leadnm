-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 14, 2025 at 02:30 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hrm`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `name`) VALUES
(1, 'Ravi'),
(2, 'Sita');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE IF NOT EXISTS `holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_date` date NOT NULL,
  `holiday_name` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `holidays`
--


-- --------------------------------------------------------

--
-- Table structure for table `leave_applications`
--

CREATE TABLE IF NOT EXISTS `leave_applications` (
  `application_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `employee_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_days` decimal(4,2) NOT NULL,
  `status` enum('Pending','Approved','Rejected','Cancelled') DEFAULT 'Pending',
  `applied_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_on` timestamp NULL DEFAULT NULL,
  `approver_id` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`application_id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `leave_applications`
--

INSERT INTO `leave_applications` (`application_id`, `created_at`, `updated_at`, `employee_id`, `leave_type_id`, `start_date`, `end_date`, `total_days`, `status`, `applied_on`, `approved_on`, `approver_id`, `remarks`) VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 1, '2025-12-13', '2025-12-13', '1.00', 'Pending', '2025-12-11 19:13:06', NULL, NULL, NULL),
(2, '2025-12-13 16:28:26', '2025-12-13 16:28:26', 1, 2, '2025-12-14', '2025-12-14', '1.00', 'Pending', '2025-12-15 00:00:00', NULL, 1, NULL),
(23, '2025-12-14 14:15:55', '2025-12-14 14:15:55', 1, 1, '2025-12-19', '2025-12-22', '4.00', 'Pending', '2025-12-15 00:00:00', NULL, 1, NULL),
(24, '2025-12-14 14:18:10', '2025-12-14 14:18:10', 1, 1, '2025-12-19', '2025-12-22', '2.00', 'Pending', '2025-12-15 00:00:00', NULL, 1, NULL),
(25, '2025-12-14 14:19:03', '2025-12-14 14:19:03', 1, 1, '2025-12-19', '2025-12-22', '4.00', 'Pending', '2025-12-15 00:00:00', NULL, 1, NULL),
(26, '2025-12-14 14:24:17', '2025-12-14 14:24:17', 1, 1, '2025-12-19', '2025-12-22', '2.00', 'Pending', '2025-12-15 00:00:00', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leave_balances`
--

CREATE TABLE IF NOT EXISTS `leave_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `allocated` decimal(5,2) DEFAULT '0.00',
  `used` decimal(5,2) DEFAULT '0.00',
  `pending` decimal(5,2) DEFAULT '0.00',
  `remaining` decimal(5,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `leave_balances`
--

INSERT INTO `leave_balances` (`id`, `employee_id`, `leave_type_id`, `allocated`, `used`, `pending`, `remaining`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '10.00', '0.00', '2.00', '2.00', '2025-12-01 00:00:00', '2025-12-14 14:24:17');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE IF NOT EXISTS `leave_types` (
  `leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `yearly_limit` decimal(5,2) NOT NULL,
  `accrual_per_month` decimal(4,2) NOT NULL,
  `allow_half_day` tinyint(1) DEFAULT '1',
  `expiry_reset` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`leave_type_id`, `name`, `yearly_limit`, `accrual_per_month`, `allow_half_day`, `expiry_reset`) VALUES
(1, 'Casual Leave', '24.00', '2.00', 1, 1),
(2, 'Unpaid Leave', '0.00', '0.00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2025_12_14_090329_create_sandwich_policy_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sandwich_policy_settings`
--

CREATE TABLE IF NOT EXISTS `sandwich_policy_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_weekly_off` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_holiday` tinyint(1) NOT NULL DEFAULT '1',
  `disable_from` date DEFAULT NULL,
  `disable_to` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sandwich_policy_settings`
--

INSERT INTO `sandwich_policy_settings` (`id`, `is_enabled`, `apply_on_weekly_off`, `apply_on_holiday`, `disable_from`, `disable_to`, `created_at`, `updated_at`) VALUES
(4, 1, 1, 1, '2025-12-19', '2025-12-22', '2025-12-14 14:17:18', '2025-12-14 14:17:18');

-- --------------------------------------------------------

--
-- Table structure for table `sandwich_policy_settings66`
--

CREATE TABLE IF NOT EXISTS `sandwich_policy_settings66` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_weekly_off` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_holiday` tinyint(1) NOT NULL DEFAULT '1',
  `disable_from` date NOT NULL,
  `disable_to` date NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sandwich_policy_settings66`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` enum('admin','employee') DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `employee_id`, `username`, `password`, `role`) VALUES
(1, 1, 'admin', 'admin', 'admin');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leave_applications`
--
ALTER TABLE `leave_applications`
  ADD CONSTRAINT `leave_applications_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  ADD CONSTRAINT `leave_applications_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`);

--
-- Constraints for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD CONSTRAINT `leave_balances_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  ADD CONSTRAINT `leave_balances_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`);
