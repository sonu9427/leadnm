<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SandwichPolicySetting extends Model
{
    use HasFactory;

    protected $table = 'sandwich_policy_settings';

    protected $fillable = [
        // 'is_enabled',
        'apply_on_weekly_off',
        'apply_on_holiday',
        'disable_from',
        'disable_to'
    ];
}
