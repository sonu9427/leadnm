-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 14, 2025 at 02:33 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hrm`
--

-- --------------------------------------------------------

--
-- Table structure for table `sandwich_policy_settings`
--

CREATE TABLE IF NOT EXISTS `sandwich_policy_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_weekly_off` tinyint(1) NOT NULL DEFAULT '1',
  `apply_on_holiday` tinyint(1) NOT NULL DEFAULT '1',
  `disable_from` date DEFAULT NULL,
  `disable_to` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sandwich_policy_settings`
--

INSERT INTO `sandwich_policy_settings` (`id`, `is_enabled`, `apply_on_weekly_off`, `apply_on_holiday`, `disable_from`, `disable_to`, `created_at`, `updated_at`) VALUES
(4, 1, 1, 1, '2025-12-19', '2025-12-22', '2025-12-14 14:17:18', '2025-12-14 14:17:18');
