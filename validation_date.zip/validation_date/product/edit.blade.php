<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>

    @if(session('success'))
        <p>{{ session('success') }}</p>
    @endif

    <form action="{{ route('product.update', $product->id) }}" method="POST">
        @csrf
        @method('PUT')

        <label for="name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" value="{{ old('product_name', $product->name) }}">
        @error('name')
            <p>{{ $message }}</p>
        @enderror

        <label for="mas_price">Price:</label>
        <input type="text" id="mas_price" name="mas_price" value="{{ old('mas_price', $product->mas_price) }}">
        @error('mas_price')
            <p>{{ $message }}</p>
        @enderror

        <button type="submit">Update Product</button>
    </form>
</body>
</html>
