<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $table = 'products';

    protected $fillable = ['product_name', 'mas_price'];

    // A product can be associated with many project products
    public function projectProducts()
    {
        return $this->hasMany(ProjectProduct::class, 'product_id');
    }
}
