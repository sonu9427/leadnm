<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    // Show the edit form for a product
    public function edit($id)
    {

        $product = Product::findOrFail($id);
        return view('product.edit', compact('product'));
    }

    public function update(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Log the product and its associated project products
        \Log::info('Product found:', ['product' => $product->toArray()]);
        \Log::info('Project Products:', ['projectProducts' => $product->projectProducts->toArray()]);

        // Check if there is any associated ProjectProduct with a related ProjectPreInstallValidation
        // that has a validation_date that is NULL
        $hasNullValidationDate = $product->projectProducts()
            ->whereHas('project', function ($query) {
                $query->whereNull('validation_date');
            })
            ->exists(); // Check if any record exists

        // Log whether there are records with NULL validation_date
        \Log::info('Has null validation_date:', ['hasNull' => $hasNullValidationDate]);

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($hasNullValidationDate) {
            // If any validation_date is NULL, update both product_name and mas_price
            \Log::info('Empty validation_date found. Updating mas_price.');
            $updateData['mas_price'] = $request->input('mas_price');
        }

        // Log the update data
        \Log::info('Update Data:', ['updateData' => $updateData]);

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
                         ->with('success', 'Product updated successfully');
    }

    public function updateDDD(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Check if there is any associated ProjectProduct with a related ProjectPreInstallValidation
        // that has a validation_date that is NULL
        $hasNullValidationDate = $product->projectProducts()
            ->whereHas('project', function ($query) {
                $query->whereNull('validation_date');
            })
            ->exists(); // Check if any record exists

        // Log whether there are records with NULL validation_date
        \Log::info('Has null validation_date:', ['hasNull' => $hasNullValidationDate]);

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($hasNullValidationDate) {
            // If any validation_date is NULL, update both product_name and mas_price
            \Log::info('Empty validation_date found. Updating mas_price.');
            $updateData['mas_price'] = $request->input('mas_price');
        }

        // Log the update data
        \Log::info('Update Data:', ['updateData' => $updateData]);

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
                         ->with('success', 'Product updated successfully');
    }

    public function update11111111(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Check if there is any associated ProjectProduct with a related ProjectPreInstallValidation
        // that has a validation_date that is NULL
        $hasNullValidationDate = $product->projectProducts()
            ->whereHas('project', function ($query) {
                $query->whereNull('validation_date');
            })
            ->exists(); // Check if any record exists

        \Log::info('Has null validation_date:', ['hasNull' => $hasNullValidationDate]);

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($hasNullValidationDate) {
            // If any validation_date is NULL, update both product_name and mas_price
            \Log::info('Empty validation_date found. Updating mas_price.');
            $updateData['mas_price'] = $request->input('mas_price');
        }

        \Log::info('Update Data:', ['updateData' => $updateData]);

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
                         ->with('success', 'Product updated successfully');
    }


    public function update333444(Request $request, $id)
    {
        // Find the product by ID or fail
       // $product = Product::findOrFail($id);

        $product = Product::findOrFail($id);

$projectProducts = $product->projectProducts()
    ->whereHas('project', function ($query) {
        $query->whereNull('validation_date');
    })
    ->get();

\Log::info('Project Products with NULL validation_date:', ['projectProducts' => $projectProducts]);

        // // Check if there is any associated ProjectProduct with a related ProjectPreInstallValidation
        // // that has a validation_date that is NULL
        // $hasNullValidationDate = $product->projectProducts()
        //     ->whereHas('project', function ($query) {
        //         $query->whereNull('validation_date');
        //     })
        //     ->exists();

        // \Log::info('Has null validation_date:', ['hasNull' => $hasNullValidationDate]);

        // // Prepare data for update
        // $updateData = ['product_name' => $request->input('product_name')];

        // if ($hasNullValidationDate) {
        //     \Log::info('Empty validation_date found. Updating mas_price.');
        //     $updateData['mas_price'] = $request->input('mas_price');
        // }

        // \Log::info('Update Data:', ['updateData' => $updateData]);

        // // Update the product with new values
        // $product->update($updateData);

        // // Redirect with success message
        // return redirect()->route('product.edit', $id)
        //                  ->with('success', 'Product updated successfully');
    }

    public function update333(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Check if there is any associated ProjectProduct with a related ProjectPreInstallValidation
        // that has a validation_date that is NULL
        $hasNullValidationDate = $product->projectProducts()
            ->whereHas('project', function ($query) {
                $query->whereNull('validation_date');
            })
            ->exists(); // Check if any record exists

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($hasNullValidationDate) {
            // If any validation_date is NULL, update both product_name and mas_price
            \Log::info('Empty validation_date found.');
            $updateData['mas_price'] = $request->input('mas_price');
        }

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
            ->with('success', 'Product updated successfully');
    }

    public function updateaaa(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Fetch all associated project products
        $projectProducts = $product->projectProducts;

        // Flag to determine if both fields should be updated
        $updateBothFields = false;

        foreach ($projectProducts as $projectProduct) {
            // Fetch associated project validation
            $projectValidation = $projectProduct->project;

            // Check if projectValidation is null before accessing its properties
            if ($projectValidation === null) {
                \Log::info('Empty validation_date found.');
                continue; // Skip this iteration if there is no associated project validation
            }

            // Check if validation_date is null or an empty string
            if (is_null($projectValidation->validation_date) || $projectValidation->validation_date === '') {
                // If any validation_date is null or empty, update both fields
                $updateBothFields = true;
                break;
            }
        }

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($updateBothFields) {
            // Add 'mas_price' to update data if any validation_date is null or empty
            $updateData['mas_price'] = $request->input('mas_price');
        }

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
            ->with('success', 'Product updated successfully');
    }


    public function update12(Request $request, $id)
    {
        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Fetch all associated project products
        $projectProducts = $product->projectProducts;

        // Flag to determine if both fields should be updated
        $updateBothFields = false;

        foreach ($projectProducts as $projectProduct) {
            // Fetch associated project validation
            $projectValidation = $projectProduct->project;

            // Check if validation_date is empty
            if (is_null($projectValidation->validation_date) || $projectValidation->validation_date === '') {
                // If any validation_date is empty, update both fields
                \Log::info('Empty validation_date found.');
                $updateBothFields = true;
                break;
            }
        }

        // Prepare data for update
        $updateData = ['product_name' => $request->input('product_name')];

        if ($updateBothFields) {
            // Add 'mas_price' to update data if any validation_date is empty
            $updateData['mas_price'] = $request->input('mas_price');
        }

        // Update the product with new values
        $product->update($updateData);

        // Redirect with success message
        return redirect()->route('product.edit', $id)
            ->with('success', 'Product updated successfully');
    }

    // Update the product
    public function update11(Request $request, $id)
    {


        // Find the product by ID or fail
        $product = Product::findOrFail($id);

        // Check if there are any associated project products
        $projectProducts = $product->projectProducts;

        // Flag to determine if price should be updated
        // $shouldUpdatePrice = true;

        foreach ($projectProducts as $projectProduct) {
            // Fetch associated project validation
            $projectValidation = $projectProduct->project;

            // $ds = $projectValidation->validation_date;
            echo "<pre>";
            print_R($projectValidation->toArray());
            exit;


            // Check if validation_date is empty
            if (empty($projectValidation->validation_date)) {
                // If any validation_date is empty, do not update the price
                exit("test11");
                // $shouldUpdatePrice = true;
                break;
            }
        }

        // Update the product based on the condition
        // if ($shouldUpdatePrice) {
        //     //exit("test12");
        //     $product->update($request->only('product_name', 'mas_price'));

        // } else {
        //    //exit("test13");
        //    $product->update($request->only('product_name'));
        // }

        // Redirect with success message
        return redirect()->route('product.edit', $id)
            ->with('success', 'Product updated successfully');
    }
}
