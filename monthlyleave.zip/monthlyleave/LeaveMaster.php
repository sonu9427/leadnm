<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveMaster extends Model
{
    use HasFactory;

    protected $table = 'leave_masters';

    protected $fillable = [
        'leave_type_id',
        'leave_plan_id',
        'yearly_limit',
        'accrual_per_month',
        'allow_half_day',
        'expiry_reset',
    ];

    public function leaveType()
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }

    public function leavePlan()
    {
        return $this->belongsTo(LeavePlan::class, 'leave_plan_id');
    }
}
