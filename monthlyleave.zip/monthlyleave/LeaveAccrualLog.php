<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveAccrualLog extends Model
{
    use HasFactory;

    protected $table = 'leave_accrual_logs';

    protected $fillable = [
        'user_id',
        'leave_type_id',
        'month',
    ];


    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function leaveType()
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }


    // Employee.php

    // public function accrualLogs()
    // {
    //     return $this->hasMany(LeaveAccrualLog::class);
    // }
}
