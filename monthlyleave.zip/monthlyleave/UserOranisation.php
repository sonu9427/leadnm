<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserOranisation extends Model
{
    use HasFactory;

    protected $table = 'user_oranisation';

    protected $fillable = [
        'user_id',
        'leave_plan_id',
        'first_name',
        'date_of_joining',
        'probation_months',
        'probation_end_date',
    ];


    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function leavePlan()
    {
        return $this->belongsTo(LeavePlan::class, 'leave_plan_id');
    }


    // ✅ ADD THIS METHOD
    // public function accrualLogs()
    // {
    //     return $this->hasMany(LeaveAccrualLog::class, 'employee_id');
    // }
}
