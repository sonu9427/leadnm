<?php

namespace App\Jobs;

use App\Models\Employee;
use App\Models\LeaveMaster;
use App\Models\LeaveBalance;
use App\Models\LeaveType;
use App\Models\LeaveAccrualLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\User;

//use DB;

class MonthlyLeaveAccrual implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        DB::transaction(function () {

            Log::info('MonthlyLeaveAccrual started');

            $month = now()->format('Y-m');

            // 1️⃣ Casual Leave Type
            $casualLeave = LeaveType::where('name', 'Casual Leave')->first();
            if (!$casualLeave) {
                Log::warning('Casual Leave not found');
                return;
            }

            // 2️⃣ Leave Master for Casual Leave
            $leaveMaster = LeaveMaster::where('leave_type_id', $casualLeave->id)->first();
            if (!$leaveMaster) {
                Log::warning('LeaveMaster not found');
                return;
            }

            $accrual = $leaveMaster->accrual_per_month;

            // 3️⃣ Users who did NOT receive accrual this month
            $users = User::whereHas('organisation') // only active employees
                ->whereDoesntHave('accrualLogs', function ($q) use ($month, $casualLeave) {
                    $q->where('month', $month)
                        ->where('leave_type_id', $casualLeave->id);
                })
                ->get();

            Log::info('Users count: ' . $users->count());

            foreach ($users as $user) {

                // 4️⃣ Fetch or create Leave Balance
                $balance = LeaveBalance::firstOrCreate(
                    [
                        'user_id'       => $user->id,
                        'leave_type_id' => $casualLeave->id,
                    ],
                    [
                        'allocated' => 0,
                        'used'      => 0,
                        'pending'   => 0,
                        'remaining' => 0,
                    ]
                );

                // 5️⃣ Accrual
                $balance->increment('allocated', $accrual);
                $balance->increment('remaining', $accrual);

                // 6️⃣ Accrual Log
                LeaveAccrualLog::create([
                    'user_id'       => $user->id,
                    'leave_type_id' => $casualLeave->id,
                    'month'         => $month,
                ]);
            }

            Log::info('MonthlyLeaveAccrual completed');
        });
    }
}
