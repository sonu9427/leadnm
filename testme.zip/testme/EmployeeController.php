<?php

namespace App\Http\Controllers;

use App\Models\Employee;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Countries;
use App\Models\State;
use App\Models\City;

class EmployeeController extends Controller
{
    public function __construct()
    {
        $this->middleware('cors');
    }
    public function index(Request $request)
    {

        $data['countries'] = Countries::get(["name", "id"])->toArray();
       // $data['states'] = State::get(["name", "id"])->toArray();

        if ($request->ajax()) {

            return $this->fetchall();

        }

        return view('index', $data);
        // return view ('employee.index');
    }

    public function store(Request $request)
    {
        // dd($request->all());
        // exit;
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:employees|max:255', // Adjust the rules as needed
            'phone' => ['required', 'unique:employees', 'regex:/^[0-9]{10}$/'],
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust the rules as needed// Adjust the regex pattern as needed
        ]);


        $file = $request->file('avatar');
        $fileName = time() . '.' . $file->getClientOriginalExtension();
        $file->storeAs('public/images', $fileName);

        $hob = implode(',', $request->hobby);

        $ds = '';
        $emp = new Employee();
        $emp->first_name = $request->first_name;
        $emp->last_name = $request->last_name;
        $emp->email = $request->email;
        $emp->phone = $request->phone;
        $emp->post = $request->post;
        $emp->avatar = $fileName;
        $emp->gender = $request->gender;
        $emp->city = $request->city;
        $emp->hobby = $hob;
        $emp->country_id = $request->country_id;
        $emp->state_id = $request->state_id;
        $emp->city_id = $request->city_id;
        $emp->save();

        return response()->json(['status' => 200,]);
        //return response()->json(['success' => 'Form submitted successfully']);


    }

    public function update(Request $request)
    {
        //exit("fdsfsdfsfd");
        $hob = implode(',', $request->hobby);

        if ($request->ajax()) {

            $emp = Employee::find($request->emp_id);
            if ($request->hasFile('avatar')) {
                $file = $request->file('avatar');
                $fileName = time() . '.' . $file->getClientOriginalExtension();
                $file->storeAs('public/images', $fileName);
                if ($emp->avatar) {
                    Storage::delete('public/images/' . $emp->avatar);
                }
            } else {
                $fileName = $request->emp_avatar;
            }
            $emp->first_name = $request->first_name;
            $emp->last_name = $request->last_name;
            $emp->email = $request->email;
            $emp->phone = $request->phone;
            $emp->post = $request->post;
            $emp->avatar = $fileName;
            $emp->gender = $request->gender;
            $emp->city = $request->city;
            $emp->hobby = $hob;
            $emp->country_id = $request->country_id;
            $emp->state_id = $request->state_id;
            $emp->city_id = $request->city_id;
            //$emp->avatar = $ds;
            $emp->save();

            return response()->json(['status' => 200,]);

        }

        // $ds = '';
        //  $emp = new Employee();


    }

    public function destroy(Request $request)
    {
        $id = $request->id;
        $emp = Employee::find($id);
        if ($emp->avatar) {
            Storage::delete('public/images/' . $emp->avatar);
        }
        Employee::destroy($id);

    }

    public function edit(Request $request)
    {

        $id = $request->id;
        $emp = Employee::find($id);
        return response()->json($emp);
    }



    public function fetchall()
    {

        $emp = Employee::all();
        $data['data'] = [];
        if ($emp->isNotEmpty()) {
            foreach ($emp as $key => $value) {
                $data['data'][] = [
                    'avatar' => '<a download="custom-filename.jpg" href="storage/images/' . $value->avatar . '" title="ImageName"><img src="storage/images/' . $value->avatar . '" width="50" alt="ImageName" class="img-thumbnail rounded-circle"></a>',
                    'first_name' => $value->first_name,
                    'email' => $value->email,
                    'phone' => $value->phone,
                    'post' => $value->post,
                    'gender' => $value->gender,
                    'city' => $value->city,
                    'action' => '<a href="#" id="' . $value->id . '" class="edit" data-bs-toggle="modal" data-url="' . route('emp.edit', $value->id) . '" data-bs-target="#editEmployeeModal">Edit</a>|<a href="#" id="' . $value->id . '" class="del" data-bs-toggle="modal" data-url="' . route('emp.destroy', $value->id) . '" data-bs-target="#deleteEmployeeModal">Delete</a>'
                ];
            }
        }

        return response()->json($data);
        // $output = " ";

    }

    public function fetchstate(Request $request)
    { 
        $country_id =  $request->country_id;
        $data['states'] = State::where('country_id',$country_id)->get()->toArray();
        return response()->json($data);
        
    }

    public function fetchcity(Request $request)
    { 
        $state_id = $request->state_id;
        $data['citys'] = City::where('state_id', $state_id )->get()->toArray();
        return response()->json($data);
          
    }


   
}
