<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee List</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css' />
  <link rel='stylesheet'
    href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css' />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/dt-1.10.25/datatables.min.css" />

  <style>
    .bg-danger1 {
      background-color: gray;
    }
  </style>

</head>

<div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="exampleModalLabel"
  data-bs-backdrop="static" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="alert alert-danger print-error-msg" style="display:none">
        <ul></ul>
      </div>


      <form action="#" method="POST" id="add_employee_form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body p-4 bg-light">

          <table>
            <tr>
              <td>First Name</td>
              <td><input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name">
                <span id="first_name_error" class="text-danger"></span>
              </td>
            </tr>

            <tr>
              <td>Last Name</td>
              <td><input type="text" name="last_name" class="form-control" placeholder="Last Name" required>
                <span id="last_name_error" class="text-danger"></span>
              </td>
            </tr>

            <tr>
              <td>Email</td>
              <td><input type="email" name="email" class="form-control" placeholder="E-mail" required>
                <span id="email_error" class="text-danger"></span>
              </td>
            </tr>
            <tr>
              <td>Phone</td>
              <td><input type="tel" name="phone" class="form-control" placeholder="Phone" required>
                <span id="phone_error" class="text-danger"></span>
              </td>
            </tr>
            <tr>
              <td>Post</td>
              <td><input type="text" name="post" class="form-control" placeholder="Post" required></td>
            </tr>

            <tr>
              <td>Image</td>
              <td><input type="file" name="avatar" class="form-control" required>
                <span id="avatar_error" class="text-danger"></span>
              </td>
            </tr>


            <tr>
              <td>Gender</td>
              <td>
                <input type="radio" name="gender" class="form-control1" value="Male">Male
                <input type="radio" name="gender" class="form-control1" value="Female">Female
              </td>
            </tr>

            <tr>
              <td>City</td>
              <td>
                <select name="city">
                  <option value="Ahmedabad">Ahmedabad</option>
                  <option value="Surat">Surat</option>
                  <option value="Baroda">Baroda</option>
                </select>
              </td>
            </tr>

            <tr>
              <td>Hobby</td>
              <td><input type="checkbox" name="hobby[]" value="Songs" class="form-control1">Songs
                <input type="checkbox" name="hobby[]" value="Dream" class="form-control2">Dream
              </td>
            </tr>

            <tr>
              <td>Country</td>
              <td>
                <select id="country-dropdown" class="form-control" name="country_id">
                  <option value="">-- Select Country --</option>
                  @foreach($countries as $key => $val)
                  <option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
                  @endforeach
                </select>
              </td>
            </tr>

            <tr>
              <td>State</td>
              <td>
                <select id="state-dropdown" class="form-control" name="state_id">
                </select>
              </td>
            </tr>

            <tr>
              <td>City</td>
              <td>
                <select id="city-dropdown" class="form-control" name="city_id">
                </select>
              </td>
            </tr>



          </table>
        </div>
        <div class="modal-footer">
          <button type="button" id="add_employee_btn" class="btn btn-primary">Add Employee</button>
          <!-- <button type="submit" id="add_employee_btn" class="btn btn-primary">Add Employee</button> -->
        </div>
      </form>
      <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    </div>
  </div>
</div>

<!-- edit form  -->

<div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="exampleModalLabel"
  data-bs-backdrop="static" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{route('emp.update', ['emp' => ':id'])}}" method="POST" id="edit_employee_form"
        enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <!-- @method('PUT') -->
        <input type="text" name="emp_id" id="emp_id">
        <input type="hidden" name="emp_avatar" id="emp_avatar">
        <div class="modal-body p-4 bg-light">

          <table>
            <tr>
              <td>First Name</td>
              <td><input type="text" name="first_name" id="fname" class="form-control" placeholder="First Name">
              </td>
            </tr>

            <tr>
              <td>Last Name</td>
              <td><input type="text" name="last_name" id="lname" class="form-control" placeholder="Last Name" required>
              </td>
            </tr>

            <tr>
              <td>Email</td>
              <td><input type="email" name="email" id="email" class="form-control" placeholder="E-mail" required></td>
            </tr>
            <tr>
              <td>Phone</td>
              <td><input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone" required></td>
            </tr>
            <tr>
              <td>Post</td>
              <td><input type="text" name="post" id="post" class="form-control" placeholder="Post" required></td>
            </tr>

            <tr>
              <td>Image</td>
              <td>
                <div class="mt-2" id="avatar"></div>
                <input type="file" name="avatar" class="form-control">
              </td>
            </tr>


            <tr>
              <td>Gender</td>
              <td>
                <div id="gen1"></div>
                <input type="radio" class="gen" name="gender" id="gender1" class="form-control1" value="Male">Male
                <input type="radio" class="gen" name="gender" id="gender2" class="form-control1" value="Female">Female
              </td>
            </tr>

            <tr>
              <td>City</td>
              <td>
                <select name="city" id="myDropdown">
                  <option value="">--Select Value--</option>
                  <option value="Ahmedabad">Ahmedabad</option>
                  <option value="Surat">Surat</option>
                  <option value="Baroda">Baroda</option>
                </select>
              </td>
            </tr>

            <tr>
              <td>Hobby</td>
              <td><input type="checkbox" name="hobby[]" value="Songs" class="form-control1 fg">Songs
                <input type="checkbox" name="hobby[]" value="Dream" class="form-control2 fg">Dream
              </td>
            </tr>

            <tr>
              <td>Country</td>
              <td>
                <select id="editcountry-dropdown" class="form-control cnt" name="country_id">
                  @foreach($countries as $key => $val)
                  <option value="{{ $val['id'] }}">{{ $val['name'] }}</option>
                  @endforeach
                </select>
              </td>
            </tr>

            <tr>
              <td>State</td>
              <td>
                <select id="editstate-dropdown" class="form-control states" name="state_id">

                </select>
              </td>
            </tr>

            <tr>
              <td>City</td>
              <td>
                <select id="editcity-dropdown" class="form-control" name="city_id">
                </select>
              </td>
            </tr>


          </table>
        </div>
        <div class="modal-footer">

          <button type="submit" id="edit_employee_btn" class="btn btn-primary">Update Employee</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- end edit form -->

<body class="bg-light">
  <div class="container">
    <div class="row my-5">
      <div class="col-lg-12">
        <div class="card shadow">
          <div class="card-header bg-danger1 d-flex justify-content-between align-items-center">
            <h3 class="text-light">Emp List</h3>
            <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addEmployeeModal"><i
                class="circle me-2"></i>Add New Emp</button>
          </div>
          <div class="card-body" id="show_all_employees">
            <!-- <h1 class="text-center text-secondary my-5">Loading...</h1> -->

            <table id="example" class="table table-striped table-sm text-center align-middle">
              <thead>
                <tr>
                  <th>Image</th>
                  <th>First Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Post</th>
                  <th>Gender</th>
                  <th>City</th>
                  <th>Action</th>
                </tr>
              </thead>
            </table>


          </div>
        </div>
      </div>
    </div>
  </div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js'></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.10.25/datatables.min.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    $(function () {



      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });

      var url = 'http://127.0.0.1:8000/emp/update';

      $("#example").DataTable({
        ajax: '{{ route('emp.index') }}',
        //ajax:url,
        columns: [
          { data: 'avatar' },
          { data: 'first_name' },
          { data: 'email' },
          { data: 'phone' },
          { data: 'post' },
          { data: 'gender' },
          { data: 'city' },
          { data: 'action' },
        ]

      });

      $('#edit_employee_form').submit(function (e) {
        e.preventDefault();
        const fd = new FormData(this);
        var url = $(this).attr('action');
        url = url.replace(':id', $(this).find('input[name="emp_id"]').val());
        //data['_token'] = $('input[name=_token]').val();
        // alert(fd.first_name);

        //console.log(url);
        $.ajax({
          //url: '{{ route('emp.index') }}',
          url: url,
          type: 'POST',
          data: fd,
          catch: false,
          contentType: false,
          processData: false,
          dataType: 'json',
          success: function (response) {
            if (response.status == 200) {
              Swal.fire(
                'Employee Update Successfully',

              )
              //fetchallemp();
              $("#example").DataTable().ajax.reload();
            }
            $('#edit_employee_form')[0].reset();
            $('#editEmployeeModal').modal('hide');
          }

        });

      });



      // $('#add_employee_btn').click(function (e) {
      //   e.preventDefault(e);
      //   var formData = new FormData($('#userForm')[0]);
      //       $.ajax({
      //           type: 'POST',
      //           url: '{{ route('emp.store') }}',
      //           data: formData,
      //          success: function (response) {
      //               // Handle success response
      //               alert(response.success);

      //               $("#example").DataTable().ajax.reload();
      //               $('#add_employee_form')[0].reset();
      //               $('#addEmployeeModal').modal('hide');
      //           },
      //           error: function (error) {
      //               // Handle validation errors
      //               if (error.status === 422) {
      //                   var errors = error.responseJSON.errors;
      //                   console.log(errors);
      //                   displayErrors(errors);
      //               }
      //           }
      //       });
      //   });

      $('#add_employee_btn').click(function () {
        var formData = new FormData($('#add_employee_form')[0]);

        $.ajax({
          type: 'POST',
          url: '{{ route('emp.store') }}',
          data: formData,
          contentType: false,
          processData: false,
          success: function (response) {
            if (response.status == 200) {
              Swal.fire(
                'Employee Added Successfully',

              )
              // $("#example").DataTable();
              $("#example").DataTable().ajax.reload();
              //fetchallemp();
            }
            //alert(response.success);
            //$("#example").DataTable().ajax.reload();
            $('#add_employee_form')[0].reset();
            $('#addEmployeeModal').modal('hide');
            // Clear the form or do any other post-submission actions
          },
          error: function (error) {
            if (error.status === 422) {
              var errors = error.responseJSON.errors;
              displayErrors(errors);
            }
          }
        });
      });

      $('#add_employee_formMM').submit(function (e) {
        e.preventDefault();
        const fd = new FormData(this);
        $.ajax({
          url: '{{ route('emp.store') }}',
          method: 'post',
          data: fd,
          catch: false,
          contentType: false,
          processData: false,
          dataType: 'json',
          success: function (response) {
            if (response.status == 200) {
              Swal.fire(
                'Employee Added Successfully',

              )
              // $("#example").DataTable();
              $("#example").DataTable().ajax.reload();
              //fetchallemp();
            }

            alert(response.success);
            $("#example").DataTable().ajax.reload();
            $('#add_employee_form')[0].reset();
            $('#addEmployeeModal').modal('hide');
          },
          error: function (error) {
            // Handle validation errors
            if (error.status === 422) {
              var errors = error.responseJSON.errors;
              displayErrors(errors);
            }
          }

        });

      });

      function displayErrors(errors) {
        // Clear previous error messages
        $('#first_name_error').text('');
        $('#last_name_error').text('');

        // Display new error messages
        if (errors.first_name) {
          $('#first_name_error').text(errors.first_name[0]);
        }

        if (errors.last_name) {
          $('#last_name_error').text(errors.last_name[0]);
        }

        if (errors.email) {
          $('#email_error').text(errors.email[0]);
        }

        if (errors.phone) {
          $('#phone_error').text(errors.phone[0]);
        }

        if (errors.avatar) {
          $('#avatar_error').text(errors.avatar[0]);
        }

        // Add similar blocks for other form fields
      }


      $('#country-dropdown').on('change', function () {

        var id = $(this).val();
        var url = new URL(document.location);
        $.ajax({
          url: "{{url('fetchstate')}}",
          //url: url.fetchstate,
          type: "POST",
          data: {
            country_id: id,
            _token: '{{csrf_token()}}'
          },
          dataType: 'json',
          success: function (result) {
            $('#state-dropdown').html('<option value="">-- Select State --</option>');
            $.each(result.states, function (key, value) {
              $('#state-dropdown').append('<option value="' + value.id + '">' + value.name + '<option>')

            });

            $('#city-dropdown').html('<option value="">-- Select City --</option>');
          }


        });

      });

      $('#editcountry-dropdown').on('change', function () {
        var id = $(this).val();
        var url = new URL(document.location);
        populateDropdown('#editstate-dropdown', id);

      });

      $('#editstate-dropdown').on('change', function () {
        var id = $(this).val();
        var url = new URL(document.location);
        populateDropdownEdit('#editcity-dropdown', id);

      });



      $('#state-dropdown').on('change', function () {
        var id = $(this).val();
        $.ajax({
          url: "{{ url('fetchcity') }}",
          type: 'POST',
          data: {
            state_id: id,
            _token: '{{csrf_token()}}'
          },
          dataType: 'json',
          success: function (result) {
            $.each(result.citys, function (key, value) {
              $("#city-dropdown").append('<option value="' + value.id + '">' + value.name + '</option>')
            });

          }

        });
      });

      function populateDropdown(selector, country_id, selectedId) {
        //  alert("gggg");

        $.ajax({
          type: 'POST',
          url: "{{url('fetchstate')}}",
          data: {
            country_id: country_id,
            _token: '{{csrf_token()}}'
          },
          dataType: 'json',
          success: function (data) {
            var dropdown = $(selector);
            dropdown.empty(); // Clear previous options
            $.each(data.states, function (key, state) {
              var selected = (typeof selectedId !== 'undefined' && selectedId == state.id) ? 'selected' : '';
              dropdown.append('<option value="' + state.id + '" ' + selected + '>' + state.name + '</option>');
            });
          },
          error: function (error) {
            console.error('Error loading data:', error);
          }
        });
      }

      function populateDropdownEdit(selector, state_id,selectedId) {

        $.ajax({
          type: 'POST',
          url: "{{url('fetchcity')}}",
          data: {
            state_id: state_id,
            _token: '{{csrf_token()}}'
          },
          dataType: 'json',
          success: function (data) {
            var dropdown = $(selector);
            dropdown.empty(); // Clear previous options
            $.each(data.citys, function (key, city) {
              var selected = (typeof selectedId !== 'undefined' && selectedId == city.id) ? 'selected' : '';
              dropdown.append('<option value="' + city.id + '" ' + selected + '>' + city.name + '</option>');
            });
          },
          error: function (error) {
            console.error('Error loading data:', error);
          }
        });

      }

      $(document).on('click', '.edit', function (e) {
        e.preventDefault();
        var id = $(this).attr('id');
        var csrf = '{{ csrf_token() }}';
        $.ajax({
          url: $(this).attr('data-url'),
          method: 'get',
          data: {
            id: id,
            _token: csrf
          },
          success: function (response) {
            console.log(response);
            let string = response.hobby;
            let arr = string.split(',');
            console.log(arr['0'])

            $("#fname").val(response.first_name);
            $("#lname").val(response.last_name);
            $("#email").val(response.email);
            $("#phone").val(response.phone);
            $("#post").val(response.post);
            $("#avatar").html(
              `<img src="storage/images/${response.avatar}" width="100" class="img-fluid img-thumbnail">`);
            // $('input[name="gender"]:checked').val(response.gender);
            $("#emp_id").val(response.id);
            $("#emp_avatar").val(response.avatar);

            var condition = response.gender;
            if (condition == 'Male') {
              $('input[name="gender"][value="Male"]').prop('checked', true);
            } else {
              $('input[name="gender"][value="Female"]').prop('checked', true);
            }

            $('#myDropdown option').each(function () {
              // Check if the option's value matches the condition
              if ($(this).val() === response.city) {
                // Set the 'selected' attribute for the matching option
                $(this).prop('selected', true);
              }
            });

            $('.cnt option').each(function () {
              if ($(this).val() == response.country_id) {
                // Set the 'selected' attribute for the matching option
                $(this).prop('selected', true);
              }

            });

            // $('#editstate-dropdown').val(response.country_id);
            populateDropdown('#editstate-dropdown', response.country_id, response.state_id);

            populateDropdownEdit('#editcity-dropdown', response.state_id, response.city_id);

            // $('.states option').each(function () {

            //   if ($(this).val() == response.state_id) {
            //     // Set the 'selected' attribute for the matching option
            //     $(this).prop('selected', true);
            //   }

            // });



            $('input[type="checkbox"]').each(function (index) {
              //if ($(this).val() == "Songs") 
              if (response.hobby.split(",").includes($(this).val())) {
                ($(this).prop('checked', true));
              } else {
                ($(this).prop('checked', false));
              }

            });

          }
        });
      });


      $(document).on('click', '.del', function (e) {
        e.preventDefault();
        var id = $(this).attr('id');
        var csrf = '{{ csrf_token() }}';
        if (confirm("Are you want to delete this record?")) {

          $.ajax({
            url: $(this).attr('data-url'),
            method: 'delete',
            data: {
              id: id,
              _token: csrf
            },
            success: function (response) {
              Swal.fire(
                'Deleted File',

              )
              // fetchallemp();
              $("#example").DataTable().ajax.reload();
            }
          });
        }


      });



      //fetchallemp();








      // function populateDataTable(data) {

      //   $("#example").DataTable().clear();
      //   $.each(data, function (index, value) {
      //     $('#example').dataTable().fnAddData([
      //       value.first_name,
      //       value.email,
      //       value.phone,
      //       value.post,
      //       '<a href="#" id="'+value.id+'" class="edit" data-bs-toggle="modal" data-bs-target="#editEmployeeModal">Edit</a>|<a href="#" id="'+value.id+'" class="del">Delete</a>'

      //     ]);


      //   });
      // }

    });

  </script>
</body>

</html>