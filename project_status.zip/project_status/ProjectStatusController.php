<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\ProjectStatusRepositoryInterface;
use Carbon\Carbon;

class ProjectStatusController extends Controller
{
    protected $projectStatusRepository;
    public function __construct(ProjectStatusRepositoryInterface $projectStatusRepository)
    {
        $this->projectStatusRepository = $projectStatusRepository;
    }

    public function index()
    {
        $statusCounts = $this->projectStatusRepository->getStatusCountsForCurrentMonth();
        
        $statusLabels = [
            1 => 'Planned',
            2 => 'Scheduled',
            3 => 'Active',
            4 => 'Completed',
            5 => 'Closed',
            6 => 'Cancelled'
        ];

        $counts = [];
        foreach ($statusCounts as $statusCount) {
            $statusLabel = $statusLabels[$statusCount->status] ?? 'Unknown';
            $counts[$statusLabel] = $statusCount->total;
        }

        return view('project_status.index', ['counts' => $counts]);
    }


    public function filter(Request $request)
    {
        // Parse the start and end dates from the request
        $startDate = Carbon::parse($request->input('start_date'));
        $endDate = Carbon::parse($request->input('end_date'));

        // Fetch the counts based on the filtered dates
        $counts = $this->projectStatusRepository->getStatusCounts($startDate, $endDate);

        // Return the counts as JSON
        return response()->json(['counts' => $counts]);
    }
}
