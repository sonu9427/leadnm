<?php

namespace App\Repositories;
use Carbon\Carbon;

interface ProjectStatusRepositoryInterface

{
    public function getStatusCountsForCurrentMonth();
    public function getStatusCounts(Carbon $startDate, Carbon $endDate): array;
}
