<!-- resources/views/project_status/index.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Project Status Counts</title>
     <!-- Include CSS for Date Range Picker -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
     <!-- Include jQuery -->
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <!-- Include Moment.js -->
     <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
     <!-- Include Date Range Picker JS -->
     <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
     <style>
        table {
            width: 50%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Project Status Counts for Current Month</h1>

    <input type="text" id="hidden-input" style="display: none;" />
    <!-- Date Range Picker Display Div -->
    <div id="daterange" style="border: 1px solid #ccc; padding: 10px; width: 250px; cursor: pointer;">
        <span>Select Date Range</span>
    </div>

    <h1 style="text-align: center;">Project Status Counts for Current Month</h1>
    
    <table id="status-counts-table">
        <thead>
            <tr>
                <th>Status</th>
                <th>Count</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($counts as $status => $count)
                <tr>
                    <td>{{ $status }}</td>
                    <td>{{ $count }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <script>
        $(function() {
            $('#daterange').daterangepicker({
                ranges: {
                    'Today': [moment().startOf('day'), moment().endOf('day')],
                    'Yesterday': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                },
                locale: {
                    format: 'YYYY-MM-DD'
                }
            }, function(start, end) {
                $('#daterange').html(
                    '<span>From: ' + start.format('YYYY-MM-DD') + ' To: ' + end.format('YYYY-MM-DD') + '</span>'
                );
    
                // Trigger AJAX call to filter data based on the selected date range
                filterData(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
            });
    
            function filterData(startDate, endDate) {
                $.ajax({
                    url: '{{ route("projectStatus.filter") }}',
                    type: 'GET',
                    data: {
                        start_date: startDate,
                        end_date: endDate
                    },
                    success: function(response) {
                        updateTable(response.counts);
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr.responseText);
                    }
                });
            }
    
            function updateTable(counts) {
                let tbody = '';
                $.each(counts, function(status, count) {
                    tbody += `<tr>
                        <td>${status}</td>
                        <td>${count}</td>
                    </tr>`;
                });
                $('#status-counts-table tbody').html(tbody);
            }
        });
    </script>
    

    
</body>
</html>
