<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    protected $table = 'leads';
    public $timestamps = false; // Disable timestamps if not used

    // Define the relationship with Project
    public function projects()
    {
        return $this->hasMany(Project::class, 'lead_id');
    }
}
