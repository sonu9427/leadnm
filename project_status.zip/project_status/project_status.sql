-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 01, 2024 at 10:32 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `importexl`
--

-- --------------------------------------------------------

--
-- Table structure for table `project_status`
--

CREATE TABLE `project_status` (
  `id` bigint UNSIGNED NOT NULL,
  `organisation_id` bigint UNSIGNED NOT NULL,
  `contact_id` bigint UNSIGNED NOT NULL,
  `project_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1: Planned, 2: Scheduled, 3: Active, 4: Completed, 5: Closed, 6: Cancelled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_status`
--

INSERT INTO `project_status` (`id`, `organisation_id`, `contact_id`, `project_no`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'P001', 1, '2024-09-01 15:36:58', '2024-08-31 15:36:58'),
(2, 2, 1, 'P002', 1, '2024-08-26 15:36:58', '2024-08-31 15:36:58'),
(3, 2, 1, 'P003', 3, '2024-08-27 15:36:58', '2024-08-31 15:36:58'),
(4, 2, 1, 'P004', 4, '2024-08-28 15:36:58', '2024-08-31 15:36:58'),
(5, 2, 1, 'P005', 5, '2024-08-31 15:36:58', '2024-08-31 15:36:58'),
(6, 2, 1, 'P006', 6, '2024-08-31 15:36:58', '2024-08-31 15:36:58'),
(7, 2, 2, 'P007', 1, '2024-08-31 15:40:39', '2024-08-31 15:40:39'),
(8, 2, 2, 'P008', 2, '2024-08-31 15:40:39', '2024-08-31 15:40:39'),
(9, 2, 2, 'P009', 3, '2024-08-28 18:30:00', '2024-08-31 15:40:39'),
(10, 1, 2, 'P010', 4, '2024-08-29 18:30:00', '2024-08-31 15:40:39'),
(11, 2, 2, 'P011', 2, '2024-08-27 18:30:00', '2024-08-31 15:40:39'),
(12, 2, 2, 'P012', 6, '2024-08-30 15:40:39', '2024-08-31 15:40:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `project_status`
--
ALTER TABLE `project_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `project_status`
--
ALTER TABLE `project_status`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
