<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Payments</title>

    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include DataTables CSS and JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
    </style>
</head>
<body>
    <h2>Project Payments Summary</h2>

    <table id="projectTable" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Project Name</th>
                <th>Total Deposit</th>
                <th>Total Refund</th>
                <th>Status Name</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <script>
        $(document).ready(function() {
            $('#projectTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "{{ route('project.index') }}", // Route to your controller
                columns: [
                    { data: 'project_id', name: 'project_id' },
                    { data: 'project_name', name: 'project_name' },
                    { data: 'total_deposit', name: 'total_deposit' },
                    { data: 'total_refund', name: 'total_refund' },
                    { data: 'status_name', name: 'status_name' },
                ]
            });
        });
    </script>
</body>
</html>
