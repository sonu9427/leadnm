<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectCustomerPayment extends Model
{
    use HasFactory;

    protected $table = 'project_customer_payments';

    protected $fillable = [
        'project_id',
        'total_paid',
        'status_id',
        'refund_type',
    ];


    /**
     * Get the user that owns the ProjectCustomerPayment
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function paymentStatus()
    {
        return $this->belongsTo(PaymentStatus::class, 'status_id');
    }

    public function project()
    {
        return $this->belongsTo(Project::class, 'project_id');
    }
}
