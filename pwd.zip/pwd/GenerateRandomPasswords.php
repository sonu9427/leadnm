<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class GenerateRandomPasswords extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'generate:random-passwords';

    /**
     * The console command description.
     */
    protected $description = 'Generate random passwords for all users';

    /**
     * Execute the console command.
     */
    public function handle()
    {


        $users = User::all();

        foreach ($users as $user) {

            if (User::where('l2_manager', $user->id)->exists()) {
                $user->roles()->sync([1]); // Manager of Manager
            } elseif (User::where('dotted_line_manager', $user->id)->exists()) {
                $user->roles()->sync([2]); // Team Leader
            } else {
                $user->roles()->sync([3]); // Employee
            }
        }


        // User::chunk(100, function ($users) {
        //     foreach ($users as $user) {

        //         // Random password generate
        //         $plainPassword = Str::password(10, true, true, true, false);

        //         $user->update([
        //             'password' => Hash::make($plainPassword), // hashed password
        //             'display_text' => $plainPassword,         // plain password (visible)
        //         ]);

        //         $this->info("Updated User ID: " . $user->id);
        //     }
        // });

        // $this->info('All user passwords updated successfully!');
        // return 0;
    }
}
