<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lead Counts</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Lead Name Count</h1>

    <form id="dateFilterForm">
        <label for="date_from">From Date:</label>
        <input type="date" id="date_from" name="date_from">
        <label for="date_to">To Date:</label>
        <input type="date" id="date_to" name="date_to">
        <button type="submit">Filter</button>
    </form>

    <table id="leadTable">
        <thead>
            <tr>
                <th>Lead Name</th>
                <th>Total Lead Name Count</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($leadCounts as $leadCount)
                <tr>
                    <td>{{ $leadCount->lead_name }}</td>
                    <td>{{ $leadCount->total_lead_name_count }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <script>
        $(document).ready(function() {
            $('#dateFilterForm').on('submit', function(e) {
                e.preventDefault(); // Prevent form from submitting normally
                
                // Get form data
                var dateFrom = $('#date_from').val();
                var dateTo = $('#date_to').val();

                $.ajax({
                    url: "{{ route('leads.index') }}",
                    method: "GET",
                    data: {
                        date_from: dateFrom,
                        date_to: dateTo
                    },
                    success: function(data) {
                        var rows = '';
                        $.each(data, function(index, lead) {
                            rows += '<tr>';
                            rows += '<td>' + lead.lead_name + '</td>';
                            rows += '<td>' + lead.total_lead_name_count + '</td>';
                            rows += '</tr>';
                        });
                        $('#leadTable tbody').html(rows);
                    }
                });
            });

            // Set default date range to current date
            var today = new Date().toISOString().split('T')[0];
            $('#date_from').val(today);
            $('#date_to').val(today);
        });
    </script>
</body>
</html>
