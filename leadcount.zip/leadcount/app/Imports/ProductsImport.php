<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;


class ProductsImport implements ToCollection, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    // public function model(array $row)
    // {
    //     return new Product([
    //         'name' => $row['name'],
    //         'description' => $row['description'],
    //         'qty' => $row['qty'],
    //     ]);
    // }

    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            $product = Product::find($row['id']);
            if (!empty($product)) {
                $product->name = $row['name'];
                $product->description = $row['description'];
                $product->qty = $row['qty'];
                $product->save();
            } else {
                $product = new Product();
                $product->name = $row['name'];
                $product->description = $row['description'];
                $product->qty = $row['qty'];
                $product->save();
            }
        }
    }
}
