-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 26, 2026 at 02:32 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `angular_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `leave_accrual_logs`
--

CREATE TABLE `leave_accrual_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `employee_id` bigint UNSIGNED NOT NULL,
  `leave_type_id` bigint UNSIGNED NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_accrual_logs`
--

INSERT INTO `leave_accrual_logs` (`id`, `employee_id`, `leave_type_id`, `month`, `created_at`, `updated_at`) VALUES
(1, 17, 1, '2026-01', '2026-01-25 02:28:27', '2026-01-25 02:28:27'),
(2, 18, 1, '2026-01', '2026-01-25 02:32:11', '2026-01-25 02:32:11'),
(3, 19, 1, '2026-01', '2026-01-26 01:06:46', '2026-01-26 01:06:46'),
(4, 20, 1, '2026-01', '2026-01-26 03:35:46', '2026-01-26 03:35:46'),
(5, 21, 1, '2026-01', '2026-01-26 03:44:09', '2026-01-26 03:44:09'),
(6, 22, 1, '2026-01', '2026-01-26 04:14:21', '2026-01-26 04:14:21'),
(7, 23, 1, '2026-01', '2026-01-26 06:56:56', '2026-01-26 06:56:56'),
(8, 24, 1, '2026-01', '2026-01-26 07:05:27', '2026-01-26 07:05:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leave_accrual_logs`
--
ALTER TABLE `leave_accrual_logs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_accrual_logs_employee_id_leave_type_id_month_unique` (`employee_id`,`leave_type_id`,`month`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leave_accrual_logs`
--
ALTER TABLE `leave_accrual_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
