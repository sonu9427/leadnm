<?php

namespace App\Jobs;

use App\Models\Employee;
use App\Models\LeaveMaster;
use App\Models\LeaveBalance;
use App\Models\LeaveType;
use App\Models\LeaveAccrualLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

//use DB;

class MonthlyLeaveAccrual implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        DB::transaction(function () {

            Log::info('MonthlyLeaveAccrual started');

            $month = now()->format('Y-m');

            // 1️⃣ Leave Master
            $leaveMaster = LeaveMaster::first();
            if (!$leaveMaster) return;

            $accrual = $leaveMaster->accrual_per_month;

            // 2️⃣ Casual Leave
            $casualLeave = LeaveType::where('name', 'Casual Leave')->first();
            if (!$casualLeave) return;

            // 3️⃣ Employees who DID NOT receive leave this month
            $employees = Employee::whereDoesntHave('accrualLogs', function ($q) use ($month, $casualLeave) {
                $q->where('month', $month)
                    ->where('leave_type_id', $casualLeave->id);
            })->get();

            Log::info('Employees count: ' . $employees->count());

            foreach ($employees as $employee) {

                // 4️⃣ Create or fetch balance
                $balance = LeaveBalance::firstOrCreate(
                    [
                        'employee_id'   => $employee->id,
                        'leave_type_id' => $casualLeave->id,
                    ],
                    [
                        'allocated' => 0,
                        'used'      => 0,
                        'pending'   => 0,
                        'remaining' => 0,
                    ]
                );

                // 5️⃣ Accrual add
                $balance->increment('allocated', $accrual);
                $balance->increment('remaining', $accrual);

                // 6️⃣ Log insert
                LeaveAccrualLog::create([
                    'employee_id'   => $employee->id,
                    'leave_type_id' => $casualLeave->id,
                    'month'         => $month,
                ]);
            }

            Log::info('MonthlyLeaveAccrual completed');
        });
    }
}

// class MonthlyLeaveAccrualM
// {
//     use Dispatchable;

//     public function handle()
//     {
//         DB::transaction(function () {

//             Log::info('MonthlyLeaveAccrual started');

//             // 1️⃣ Get accrual value
//             $leaveMaster = LeaveMaster::first();

//             if (!$leaveMaster) {
//                 Log::error('LeaveMaster not found');
//                 return;
//             }

//             $accrual = $leaveMaster->accrual_per_month;

//             // 2️⃣ Get ONLY Casual Leave
//             $casualLeave = LeaveType::where('name', 'Casual Leave')->first();

//             if (!$casualLeave) {
//                 Log::error('Casual Leave not found');
//                 return;
//             }

//             // 3️⃣ Loop employees ONLY
//             // $employees = Employee::all();

//             $month = now()->format('Y-m');

//             $employees = Employee::whereDoesntHave('accrualLogs', function ($q) use ($month, $casualLeave) {
//                 $q->where('month', $month)
//                     ->where('leave_type_id', $casualLeave->id);
//             })->get();

//             foreach ($employees as $employee) {

//                 $balance = LeaveBalance::firstOrCreate(
//                     [
//                         'employee_id' => $employee->id,
//                         'leave_type_id' => $casualLeave->id,
//                     ],
//                     [
//                         'allocated' => 0,
//                         'used' => 0,
//                         'pending' => 0,
//                         'remaining' => 0,
//                     ]
//                 );

//                 // 4️⃣ Add monthly accrual
//                 $balance->increment('allocated', $accrual);
//                 $balance->increment('remaining', $accrual);

//                 // 6️⃣ Log insert
//                 LeaveAccrualLog::create([
//                     'employee_id'   => $employee->id,
//                     'leave_type_id' => $casualLeave->id,
//                     'month'         => $month,
//                 ]);
//             }

//             Log::info('MonthlyLeaveAccrual completed');
//         });
//     }
// }
