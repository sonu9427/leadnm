<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveAccrualLog extends Model
{
    use HasFactory;

    protected $table = 'leave_accrual_logs';

    protected $fillable = [
        'employee_id',
        'leave_type_id',
        'month',
    ];


    // Employee.php

    public function accrualLogs()
    {
        return $this->hasMany(LeaveAccrualLog::class);
    }
}
