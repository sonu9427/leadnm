<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    protected $table = 'employees';

    protected $fillable = [
        'leave_plan_id',
        'name',
        'date_of_joining',
        'probation_months',
        'probation_end_date',
    ];


    // ✅ ADD THIS METHOD
    public function accrualLogs()
    {
        return $this->hasMany(LeaveAccrualLog::class, 'employee_id');
    }
}
