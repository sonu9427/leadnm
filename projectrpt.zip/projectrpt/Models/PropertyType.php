<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PropertyType extends Model
{
    use HasFactory;

    protected $table = 'property_type';

    protected $fillable = ['property_type'];

    public function contacts()
    {
        return $this->hasMany(Contact::class, 'property_type_id', 'id');
    }
}
