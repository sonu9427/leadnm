<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Lead;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class LeadController extends Controller
{
    public function index22(Request $request)
    {
        $username = DB::table('users')->pluck('name', 'id');
        $user_id = $request->user_id;
        $query = Lead::select('lead_name', DB::raw('COALESCE(COUNT(projects.id), 0) as total_lead_name_count'))
            ->leftJoin('projects', 'leads.id', '=', 'projects.lead_id');

        if (!empty($request->input('date_from'))) {

            $dateFrom = $request->input('date_from');
            $dateTo = $request->input('date_to');
            $dateFrom = $dateFrom ? Carbon::parse($dateFrom)->startOfDay() : $dateFrom;
            $dateTo = $dateTo ? Carbon::parse($dateTo)->endOfDay() : $dateTo;
            $query->whereBetween('projects.created_at', [$dateFrom, $dateTo]);
            if ($user_id) {
                $query->where('projects.user_id', $user_id);
            }

            $query->groupBy('leads.id', 'leads.lead_name')
                ->having('total_lead_name_count', '>', 0);

            // Execute the query
            $leadCounts = $query->get();
            return response()->json($leadCounts);
        } else {

            $currentDate = Carbon::now()->format('Y-m-d');
            $dateFrom = Carbon::parse($currentDate)->startOfDay();
            $dateTo = Carbon::parse($currentDate)->endOfDay();
            $query->whereBetween('projects.created_at', [$dateFrom, $dateTo]);
            if ($user_id) {
                $query->where('projects.user_id', $user_id);
            }

            $query->groupBy('leads.id', 'leads.lead_name')
                ->having('total_lead_name_count', '>', 0);
            $leadCounts = $query->get();
        }

        return view('lead.index', compact('leadCounts', 'username'));
    }


    public function index(Request $request)
    {
        $username = DB::table('users')->pluck('name', 'id');
        $user_id = $request->user_id;

        // Base query
        $query = Lead::select('lead_name', DB::raw('COALESCE(COUNT(projects.id), 0) as total_lead_name_count'))
            ->leftJoin('projects', 'leads.id', '=', 'projects.lead_id');

        // Date filtering
        $dateFrom = $request->input('date_from') ? Carbon::parse($request->input('date_from'))->startOfDay() : Carbon::now()->startOfDay();
        $dateTo = $request->input('date_to') ? Carbon::parse($request->input('date_to'))->endOfDay() : Carbon::now()->endOfDay();

        $query->whereBetween('projects.created_at', [$dateFrom, $dateTo]);

        // User ID filtering
        if ($user_id) {
            $query->where('projects.user_id', $user_id);
        }

        // Group and filter results
        $query->groupBy('leads.id', 'leads.lead_name')
            ->having('total_lead_name_count', '>', 0);

        // Execute the query
        $leadCounts = $query->get();

        // Return response based on the request type
        if ($request->ajax()) {
            return response()->json($leadCounts);
        } else {
            return view('lead.index', compact('leadCounts', 'username'));
        }
    }


    public function index1(Request $request)
    {
        // Get current date range

        $username = DB::table('users')->pluck('name', 'id');

        $currentDate = Carbon::now()->format('Y-m-d');
        $dateFrom = Carbon::parse($currentDate)->startOfDay();
        $dateTo = Carbon::parse($currentDate)->endOfDay();

        // Check if the request is AJAX
        if ($request->ajax()) {
            $user_id = $request->user_id;
            $dateFrom = $request->input('date_from');
            $dateTo = $request->input('date_to');

            $dateFrom = $dateFrom ? Carbon::parse($dateFrom)->startOfDay() : $dateFrom;
            $dateTo = $dateTo ? Carbon::parse($dateTo)->endOfDay() : $dateTo;

            $query = Lead::select('lead_name', DB::raw('COALESCE(COUNT(projects.id), 0) as total_lead_name_count'))
                ->leftJoin('projects', 'leads.id', '=', 'projects.lead_id')
                ->whereBetween('projects.created_at', [$dateFrom, $dateTo]);

            // Optionally, you can filter by user_id if it's provided
            if ($user_id) {
                $query->where('projects.user_id', $user_id);
            }

            $query->groupBy('leads.id', 'leads.lead_name')
                ->having('total_lead_name_count', '>', 0);

            // Execute the query
            $leadCounts = $query->get();

            // echo "<pre>";
            // print_R($leadCounts->toArray());
            // exit;

            // Return the results as JSON
            return response()->json($leadCounts);
        }

        // If not AJAX, return the standard view with current date counts
        $leadCounts = Lead::select('lead_name', DB::raw('COALESCE(COUNT(projects.id), 0) as total_lead_name_count'))
            ->leftJoin('projects', 'leads.id', '=', 'projects.lead_id')
            ->whereBetween('projects.created_at', [$dateFrom, $dateTo])
            ->groupBy('leads.id', 'leads.lead_name')
            ->having('total_lead_name_count', '>', 0)  // Filter out leads with a count of 0
            ->get();

        return view('lead.index', compact('leadCounts', 'username'));
    }


    public function fetchusernm(Request $request)
    {
        $user_id = $request->user_id;
    }
}
