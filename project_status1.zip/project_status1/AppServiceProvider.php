<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repositories\ProjectStatusRepositoryInterface;
use App\Repositories\ProjectStatusRepository;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register()
    {
        // Bind the repository interface to the implementation
        $this->app->bind(ProjectStatusRepositoryInterface::class, ProjectStatusRepository::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
