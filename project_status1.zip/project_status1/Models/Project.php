<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $table = 'projects';
    public $timestamps = true; // Enable timestamps if used

    // Define the relationship with Lead
    public function lead()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }
}
