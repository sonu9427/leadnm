<?php

// app/Repositories/ProjectStatusRepository.php

namespace App\Repositories;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ProjectStatusRepository implements ProjectStatusRepositoryInterface
{
    public function getStatusCountsForCurrentMonth()
    {
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now()->endOfMonth();

        return DB::table('project_status')
            ->select('status', DB::raw('count(*) as total'))
            ->whereBetween('created_at', [$startOfMonth, $endOfMonth])
            ->groupBy('status')
            ->get();
    }

    public function getStatusCounts($startDate = null, $endDate = null)
    {
        //$projects = DB::table('project_status')->whereBetween('created_at', [$startDate, $endDate])->dd();
       
        // Query to get the counts of each status within the date range
        
       // echo $startDate;
         //   exit;

        $query = DB::table('project_status')
            ->select('status', DB::raw('count(*) as total'))
           // ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('status');
           
            

            if ($startDate && $endDate) {
                $startDate = Carbon::parse($startDate);
                $endDate = Carbon::parse($endDate);
                $startDate = $startDate->startOfDay();
                $endDate = $endDate->endOfDay();
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }else{
                
                $startOfMonth = Carbon::now()->startOfMonth();
                $endOfMonth = Carbon::now()->endOfMonth();
                $query->whereBetween('created_at', [$startOfMonth, $endOfMonth]);

            }

            $statusCounts = $query->pluck('total', 'status')->toArray();
            

        // Map status codes to readable labels
        $statusLabels = [
            1 => 'Planned',
            2 => 'Scheduled',
            3 => 'Active',
            4 => 'Completed',
            5 => 'Closed',
            6 => 'Cancelled'
        ];

        // Prepare the result with readable labels
        $counts = [];
        foreach ($statusLabels as $key => $label) {
            $counts[$label] = $statusCounts[$key] ?? 0;
        }

        return $counts;
    }
}
