<?php

namespace App\Http\Controllers\Api\Register;

use App\Http\Controllers\Controller;
use App\Models\Detail;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        // Basic validation
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'email' => 'required|email|unique:users',
        //     'password' => 'required|string|min:6',
        // ]);

        $user = User::create([
            'name' => $request->name,
            'mobile' => $request->mobile,
            // 'password' => Hash::make($request->password),
        ]);

        return response()->json(['message' => 'User Registered Successfully', 'user' => $user], 201);
    }

    public function getUser(Request $request)
    {
        $users = User::get();

        $data = [];

        foreach ($users as $key => $user) {
            $data[]  = [
                'id' => $user->id,
                'name' => $user->name,
                'mobile' => $user->mobile,
                'is_checked' => $user->is_checked,
            ];
        }

        return response()->json(['message' => 'User Get Successfully', 'user' => $data], 201);
    }

    public function addUser(Request $request)
    {
        $names = ['Vimal1', 'Nihar1'];

        $existingUser = Detail::whereIn('name', $names)->pluck('name')->toArray();

        if (!empty($existingUser)) {
            $disName = implode(", ", $existingUser);
            return response()->json([
                'message' => 'Users Alredy Taken into DB',
                'user' => $disName,
            ], 404);
        }

        // Create users that don't exist
        $createdUsers = [];
        foreach ($names as $name) {
            $createdUsers[] = Detail::create([
                'name' => $name,
            ]);
        }

        return response()->json([
            'message' => 'Users stored as JSON',
            'users' => $createdUsers,
        ], 201);
    }

    public function updateChk(Request $request)
    {
        $ids = $request->input('ids');
        $isChecked = $request->input('is_checked', 'yes');

        // Split the comma-separated IDs
        $idArray = explode(',', $ids);

        // Update users with is_checked = 'yes'
        User::whereIn('id', $idArray)->update([
            'is_checked' => $isChecked
        ]);

        return response()->json([
            'message' => 'Users updated successfully',
            'updated_ids' => $idArray,
        ], 200);
    }
}
