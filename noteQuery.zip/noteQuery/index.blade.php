<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>

    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-icons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/datatables.min.css') }}">

    <style>
        .bg-danger1 {
            background-color: gray;
        }
    </style>
    <script src='{{ asset('assets/js/bootstrap.bundle.min.js') }}'></script>
    <script src='{{ asset('assets/js/jquery.min.js') }}'></script>
    <script src='{{ asset('assets/js/datatables.min.js') }}'></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(function() {
            function loadData(roleId = '', dt = '') {
        // Destroy the existing DataTable if it's already initialized
        if ($.fn.dataTable.isDataTable('#listtable')) {
            $('#listtable').DataTable().destroy();
        }

        // Reinitialize the DataTable with the new data
        $('#listtable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('list') }}",
                data: {
                    role_id: roleId,
                    dt: dt
                }
            },
            columns: [
                { data: 'user_name' },
                { data: 'full_name' },
                { data: 'role_name' },
                { data: 'date_hired' },
                { data: 'action' }
            ],
            stateSave: true,  // Optional: keeps the state of the table (sorting, pagination, etc.)
        });
    }

    loadData();
                

            $('#add_employee_btn').click(function(e) {
                e.preventDefault(); // Prevent form from submitting normally
                var formData = new FormData($('#add_employee_form')[0]);
                $.ajax({
                    type: 'POST',
                    url: '{{ route('store') }}',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.status == 201) {
                            Swal.fire('Employee Added Successfully');
                            $("#example").DataTable().ajax.reload();
                        }
                        $('#add_employee_form')[0].reset();
                        $('#addEmployeeModal').modal('hide');
                    },
                    error: function(error) {
                        if (error.status === 422) {
                            var errors = error.responseJSON.errors;
                            displayErrors(errors);
                        }
                    }
                });
            });

            loadData();

            $('#roles_id').on('change', function () {
                var roleid = $(this).val();
                $('#listtable').DataTable().destroy();
                loadData(roleid); // Reload data with selected role
            });

            $('#date-filter').on('change', function () {
                var date = $(this).val();
                var roleId = $('#roles_id').val();
                $('#listtable').DataTable().destroy(); // Destroy previous instance
                loadData(roleId, date); // Reload data with selected role and date
            });

            $(document).on('click', '#edituser', function(e) {
                e.preventDefault();
                var url = $(this).data('url');
                $.ajax({
                    url: url,
                    type: 'GET',
                    success: function(response) {
                        // Handle the response
                        $("#user_name").val(response.user_name);
                        $("#first_name").val(response.organization.first_name);
                        $("#last_name").val(response.organization.last_name);
                        $("#date_hired").val(response.organization.date_hired);
                        $("#email").val(response.email);
                        $("#fulladdress").val(response.address.fulladdress);
                        
                        $('#is_active option').each(function(){
                            if($(this).val() == response.is_active)
                            {
                               $(this).prop('selected',true);
                            }                
                        });

                        $('#role_id option').each(function(){
                            if($(this).val() == response.roles[0].pivot.role_id)
                            {
                                $(this).prop('selected',true);
                            }     
                        });
                        
                        $('#role_id option').each(function(){
                            var role = $(this).val();
                           
                        })
                    },
                    error: function(xhr, status, error) {
                        console.log("Error:", error);
                    }
                });
            });

        });
        
        $(document).on('click', '#deleteChk', function(e) {
            $del_id = $('#deleteUser').prop('checked',true)
            alert($del_id);
        });    

        
    </script>
</head>

<div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="exampleModalLabel" data-bs-backdrop="static" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="alert alert-danger print-error-msg" style="display:none">
                <ul></ul>
            </div>

            {{-- <form method="post" action="#" id="add_employee_form" enctype="multipart/form-data">
                @csrf
                <div class="modal-body p-4 bg-light">
                    <table>
                        <tr>
                            <td>First Name</td>
                            <td><input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name">
                                <span id="first_name_error" class="text-danger"></span>
                            </td>
                        </tr>

                        <tr>
                            <td>Last Name</td>
                            <td><input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name" required>
                                <span id="last_name_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type="email" name="email" id="email" class="form-control" placeholder="E-mail" required>
                                <span id="email_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Date Hired</td>
                            <td><input type="text" name="date_hired" id="date_hired" class="form-control" placeholder="Post" required></td>
                        </tr>
                        <tr>
                            <td>Image</td>
                            <td><input type="file" name="avatar" class="form-control" required>
                                <span id="avatar_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Employee Id</td>
                            <td><input type="text" name="employee_id" id="employee_id" class="form-control" placeholder="Last Name" required>
                                <span id="last_name_error" class="text-danger"></span>
                            </td>
                        </tr>
                    </table>

                    <div class="modal-footer">
                        <button class="btn btn-primary" id="add_employee_btn">Update Employee</button>
                    </div>

                </div>

            </form> --}}
        </div>

    </div>

</div>

<div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="exampleModalLabel" data-bs-backdrop="static" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="alert alert-danger print-error-msg" style="display:none">
                <ul></ul>
            </div>

            
            <form method="post" action="{{ route('store') }}" id="add_employee_form" enctype="multipart/form-data">    
                @csrf
                <div class="modal-body p-4 bg-light">
                    <table>
                        <tr>
                            <td>First Name</td>
                            <td><input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name">
                                <span id="first_name_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td><input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name" required>
                                <span id="last_name_error" class="text-danger"></span>
                            </td>
                        </tr>

                        <tr>
                            <td>User Name</td>
                            <td><input type="text" name="user_name" id="user_name" class="form-control" placeholder="Last Name" required>
                                <span id="user_name_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type="email" name="email" id="email" class="form-control" placeholder="E-mail" required>
                                <span id="email_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Full Address</td>
                            <td><textarea name="fulladdress" id="fulladdress"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>Date Hired</td>
                            <td><input type="date" name="date_hired" id="date_hired" class="form-control" placeholder="Post" required></td>
                        </tr>
                        <tr>
                            <td>Image</td>
                            <td><input type="file" name="avatar" class="form-control" required>
                                <span id="avatar_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Employee Id</td>
                            <td><input type="text" name="employee_id" id="employee_id" value="{{ $employee_id }}" class="form-control" placeholder="Last Name" required>
                                <span id="last_name_error" class="text-danger"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td><select name="is_active" id="is_active">
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Roles</td>
                            <td><select name="role_id" id="role_id" class="form-control">
                                <option value="">Select Role</option>
                                @foreach($roles as $id => $name)
                                    <option value="{{ $id }}">{{ $name }}</option>
                                @endforeach
                            </select>
                            </td>
                        </tr>
                    </table>

                    <div class="modal-footer">
                        <button class="btn btn-primary" id="add_employee_btn">Submit</button>
                    </div>

                </div>

            </form>
        </div>

    </div>

</div>
<body class="bg-light">
    <div class="container">
        <div class="row my-5">
            <div class="col-lg-12">
                <div class="card shadow">
                    <div class="card-header bg-danger1 d-flex justify-content-between align-items-center">
                        <h3 class="text-light">User List</h3>
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addEmployeeModal"><i class="circle me-2"></i>Add New Emp</button>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="text-light">User List</h3>
                        <input type="date" name="date-filter" id="date-filter">
                        <select name="roles_id" id="roles_id" class="form-control1">
                            <option value="">Select Role</option>
                            @foreach($roles as $id => $name)
                                <option value="{{ $id }}">{{ $name }}</option>
                            @endforeach
                        </select>
                        <button id="deleteChk">Delete</button>
                    </div>
                    <div class="card-body" id="show_all_employees">
                        <!-- <h1 class="text-center text-secondary my-5">Loading...</h1> -->

                        <table id="listtable" class="table table-striped table-sm text-center align-middle">
                            <thead>
                                <tr>
                                    <th>User Name</th>
                                    <th>Full Name</th>
                                    <th>Role</th>
                                    <th>Date Hired</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>