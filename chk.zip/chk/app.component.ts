import { Component } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
})
export class AppComponent {
  days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  shiftForm: FormGroup;

  // backend endpoint - change to your real endpoint
  private saveUrl = 'http://localhost:8000/api/shifts/save';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.shiftForm = this.fb.group({
      shifts: this.fb.array([this.createShift()]),
    });
  }

  get shifts(): FormArray {
    return this.shiftForm.get('shifts') as FormArray;
  }

  createShift(): FormGroup {
    return this.fb.group({
      shiftName: ['', Validators.required],
      code: ['', Validators.required],
      days: this.fb.group({
        Monday: [false],
        Tuesday: [false],
        Wednesday: [false],
        Thursday: [false],
        Friday: [false],
        Saturday: [false],
        Sunday: [false],
      }),
      start_time: ['', Validators.required],
      end_time: ['', Validators.required],
      break_duration: [0],
    });
  }

  addShift() {
    this.shifts.push(this.createShift());
  }

  removeShift(index: number) {
    this.shifts.removeAt(index);
  }

  submit() {
    // mark controls as touched to show validation state
    this.shiftForm.markAllAsTouched();

    if (this.shiftForm.invalid) {
      console.error('Form invalid - please fill required fields.');
      console.log(this.shiftForm.value);
      return;
    }

    const raw = this.shiftForm.value;
    const payload = {
      shifts: raw.shifts.map((s: any) => ({
        shiftName: s.shiftName,
        code: s.code,
        days: Object.keys(s.days).filter((d) => s.days[d]),
        start_time: s.start_time,
        end_time: s.end_time,
        break_duration: s.break_duration,
      })),
    };

    console.log('Prepared payload:', payload);

    // send to backend (replace URL with your API)
    this.http.post(this.saveUrl, payload).subscribe({
      next: (res) => {
        console.log('Save success', res);
      },
      error: (err) => {
        console.error('Save failed', err);
      },
    });
  }
}
