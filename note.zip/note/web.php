<?php

use Illuminate\Support\Facades\Route;
//use App\Http\Controllers\ColumnSearchingController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProjectCustomerPaymentController;
use App\Http\Controllers\ColumnSearchingController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Route::resource('search',[ColumnSearchingController::class,'index']);


Route::resource('search', 'App\Http\Controllers\ColumnSearchingController');

Route::resource('products', ProductController::class);

Route::resource('project', ProjectCustomerPaymentController::class);

// web.php
Route::post('/payments/generate-pdf', [ProjectCustomerPaymentController::class, 'generatePdf'])->name('payments.generatePdf');

