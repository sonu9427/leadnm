<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\PurchaseOrder;

class AccountController extends Controller
{
    public function registration()
    {
        return view('front/account/registration');
    }

    public function processRegister(Request $request)
    {
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $users =  $user->save();
        return $users;
    }

    public function login()
    {
        return view('front/account/login');
    }

    public function authenticate(Request $request)
    {
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->route('account.profile');
        } else {
            return redirect()->route('account.login');
        }
    }

    public function profile()
    {
        return view('front/account/profile');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('account.login');
    }

    public function show()
    {
        //exit("ffffffffffffffff");
        $purchase_order_id = '5';
        $purchaseOrder = PurchaseOrder::with(['purchaseProducts.product', 'purchaseProducts.category'])
            ->findOrFail($purchase_order_id);

        // echo "<pre>";
        // print_R($purchaseOrder->toArray());
        // exit;

        return view('front.account.show', compact('purchaseOrder'));
    }
}
