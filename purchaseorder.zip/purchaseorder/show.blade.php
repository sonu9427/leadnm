<table border="1">
    <thead>
        <tr>
            <th>Stock Code</th>
            <th>Category Name</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($purchaseOrder->purchaseProducts as $product)
            <tr>
                <td>{{ $product->product->stock_code ?? 'N/A' }}</td>
                <td>{{ $product->category->category_name ?? 'N/A' }}</td>
                <td>{{ $product->product_name }}</td>
                <td>{{ $product->quantity }}</td>
                <td>{{ $product->price }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
