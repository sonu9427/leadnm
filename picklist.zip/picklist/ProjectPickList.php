<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectPickList extends Model
{
    use HasFactory;

    protected $table = 'project_picklists';

    protected $fillable = [
        'product_name',
        'quantity',
        'is_picklist',
        'is_dispatch',
        'is_dispatch_deduct',
    ];
}
