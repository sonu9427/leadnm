import { NgFor } from '@angular/common';
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MyService } from '../services/my.service';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  //template: '<h1>Profile Component</h1>', // <-- Correct
  // OR, if you have a separate HTML file:
  imports: [FormsModule, RouterModule, CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css',
})
export class ProfileComponent {
  successMessage: string = '';
  constructor(private myService: MyService, private router: Router) {}

  // onSubmit(form: NgForm) {
  //   const productName = form.value.productName;
  //   const quantity = form.value.quantity;
  //   console.log('Form Data:', form.value);
  //   this.myService.register(productName, quantity).subscribe(
  //     (res) => {
  //       console.log('Registration success:', res);
  //       this.successMessage = (res as any).message;
  //       form.reset();

  //       //this.router.navigate(['/dashboard']); // Only navigate if registration is successful
  //       setTimeout(() => {
  //         this.router.navigateByUrl('/dashboard');
  //       }, 2000);
  //     },
  //     (err) => {
  //       console.log('Registration error:', err);
  //     }
  //   );
  // }

  save(form: NgForm, type: string) {
    const payload = {
      productName: form.value.productName,
      quantity: form.value.quantity,
    };

    console.log('Payload:', payload);
    console.log('Type:', type);
    this.myService.register(type, payload).subscribe(
      (res) => {
        console.log('Registration success:', res);
        this.successMessage = (res as any).message;
        form.reset();

        //this.router.navigate(['/dashboard']); // Only navigate if registration is successful
        setTimeout(() => {
          this.router.navigateByUrl('/dashboard');
        }, 2000);
      },
      (err) => {
        console.log('Registration error:', err);
      }
    );
  }
}

// export class ProfileComponent {
//   constructor(private myService: MyService) {}

//   onSubmit(form: NgForm) {
//     const name = form.value.name;
//     const email = form.value.email;
//     const password = form.value.password;
//     console.log('GegValue:-', form.value);
//     this.myService.register(name, email, password).subscribe(
//       (res) => {
//         console.log(res);
//       },
//       (err) => {
//         console.log(err);
//       }
//     );
//   }
// }
