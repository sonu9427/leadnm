<?php

namespace App\Http\Controllers\Api\Register;

use App\Http\Controllers\Controller;
use App\Models\AdditionalMaterial;
use App\Models\Detail;
use App\Models\ProjectPickList;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    public function register1111(Request $request)
    {

        Log::info($request->All());

        // Basic validation
        $request->validate([
            'productName' => 'required',
            'quantity' => 'required',

        ]);

        $user = ProjectPickList::create([
            'product_name' => $request->productName,
            'quantity' => $request->quantity,
        ]);

        return response()->json(['message' => 'User Registered Successfully', 'user' => $user], 201);
    }

    public function register(Request $request)
    {

        $type = $request->type;
        $data = $request->payload;
        //Log::info($data);

        $productName = $data['productName'];
        $quantity = $data['quantity'];

        $result = null;
        $user   = null;

        if ($type == 'picklist') {

            $record = ProjectPickList::where('product_name', $productName)->first();

            if ($record) {
                // Increment quantity
                $record->quantity += $quantity;
                $record->save();
                $result = $record;
            } else {
                // Insert new record
                $result = ProjectPickList::create([
                    'product_name'       => $productName,
                    'quantity'           => $quantity,
                    'is_picklist'        => 'yes',
                    'is_dispatch'        => 'no',
                    'is_dispatch_deduct' => 'no'
                ]);
            }

            $user = AdditionalMaterial::create([
                'product_name'       => $productName,
                'quantity'           => $quantity,
                'is_picklist'        => 'yes',
                'is_dispatch'        => 'no',
                'is_dispatch_deduct' => 'no'
            ]);
        }

        if ($type == 'dispatch') {
            $picklist = ProjectPickList::where('product_name', $productName)->first();
            if ($picklist) {
                $picklist->is_dispatch = 'yes';
                $picklist->is_dispatch_deduct = 'yes';
                $picklist->save();
            }

            $add = AdditionalMaterial::where('product_name', $productName)->first();
            if ($add) {
                $add->is_dispatch = 'yes';
                $add->is_dispatch_deduct = 'yes';
                $add->save();
            }
        }


        return response()->json([
            'message' => 'Picklist saved successfully',
            'project_picklist' => $result,
            'additional_material' => $user
        ], 201);

        //return response()->json(['message' => 'User Registered Successfully', 'user' => $user], 201);
    }

    public function getUser(Request $request)
    {
        $users = User::get();

        $data = [];

        foreach ($users as $key => $user) {
            $data[]  = [
                'name' => $user->name,
                'email' => $user->email,
            ];
        }

        return response()->json(['message' => 'User Get Successfully', 'user' => $data], 201);
    }

    public function addUser(Request $request)
    {
        $names = ['Vimal1', 'Nihar1'];

        $existingUser = Detail::whereIn('name', $names)->pluck('name')->toArray();

        if (!empty($existingUser)) {
            $disName = implode(", ", $existingUser);
            return response()->json([
                'message' => 'Users Alredy Taken into DB',
                'user' => $disName,
            ], 404);
        }

        // Create users that don't exist
        $createdUsers = [];
        foreach ($names as $name) {
            $createdUsers[] = Detail::create([
                'name' => $name,
            ]);
        }

        return response()->json([
            'message' => 'Users stored as JSON',
            'users' => $createdUsers,
        ], 201);
    }
}
