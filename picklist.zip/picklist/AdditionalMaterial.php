<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdditionalMaterial extends Model
{
    use HasFactory;
    protected $table = 'additional_material';

    protected $fillable = [
        'product_name',
        'quantity',
        'is_picklist',
        'is_dispatch',
        'is_dispatch_deduct',
    ];
}
