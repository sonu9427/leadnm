import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MyService {
  constructor(private http: HttpClient) {}
  private apiUrl = 'http://localhost:8000/api/register';
  private apiUrlGetUser = 'http://localhost:8000/api/getuser';
  private apiUrlUpdateChecked = 'http://localhost:8000/api/updatechecked';

  private apiUrlg = 'http://localhost:8000/api/shifts';

  register(name: string, mobile: string) {
    const data = {
      name: name,
      mobile: mobile,
    };
    return this.http.post(this.apiUrl, data);
  }

  updateChecked(ids: string) {
    const data = {
      ids: ids,
      is_checked: 'yes',
    };
    return this.http.post(this.apiUrlUpdateChecked, data);
  }

  getUsers() {
    return this.http.get(this.apiUrlGetUser);
  }

  searchShifts(search: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrlg}?search=${search}`);
  }
}
