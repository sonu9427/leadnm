import { Component } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormsModule,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { debounceTime, Subject, switchMap } from 'rxjs';
import { MyService } from './services/my.service';

@Component({
  selector: 'app-root',
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
})
export class AppComponent {
  days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  shiftForm: FormGroup;

  search$ = new Subject<string>();
  suggestions: any[] = [];
  selectedText = '';

  //http://localhost:8000/api/register

  // backend endpoint - change to your real endpoint
  private saveUrl = 'http://localhost:8000/api/shifts/save';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private myService: MyService
  ) {
    this.shiftForm = this.fb.group({
      shifts: this.fb.array([this.createShift()]),
    });
  }

  get shifts(): FormArray {
    return this.shiftForm.get('shifts') as FormArray;
  }

  createShift(): FormGroup {
    return this.fb.group({
      // shiftName: ['', Validators.required],
      days: ['', Validators.required],
      // days: this.fb.group({
      //   Monday: [false],
      //   Tuesday: [false],
      //   Wednesday: [false],
      //   Thursday: [false],
      //   Friday: [false],
      //   Saturday: [false],
      //   Sunday: [false],
      // }),
      start_time: ['', Validators.required],
      end_time: ['', Validators.required],
      break_duration: [0],
    });
  }

  addShift() {
    this.shifts.push(this.createShift());
  }

  removeShift(index: number) {
    this.shifts.removeAt(index);
  }

  ngOnInit() {
    this.search$
      .pipe(
        debounceTime(200),
        switchMap((text) => this.myService.searchShifts(text))
      )
      .subscribe((results) => {
        this.suggestions = results;
      });
  }

  onInput(event: any) {
    const value = event.target.value;
    this.selectedText = value;
    this.search$.next(value);
  }

  chooseSuggestion(item: any) {
    this.selectedText = item.shift_name;
    this.suggestions = [];
  }

  submit() {
    // mark controls as touched to show validation state
    // this.shiftForm.markAllAsTouched();

    // if (this.shiftForm.invalid) {
    //   console.error('Form invalid - please fill required fields.');
    //   console.log(this.shiftForm.value);
    //   return;
    // }

    const raw = this.shiftForm.value;
    const payload = {
      shifts: raw.shifts.map((s: any) => ({
        shiftName: s.shiftName?.trim() || '',
        code: s.code?.trim() || '',
        days: Object.keys(s.days).filter((d) => s.days[d]),
        start_time: s.start_time || '',
        end_time: s.end_time || '',
        break_duration: parseInt(s.break_duration) || 0,
      })),
    };

    console.log('Prepared payload:', payload);

    // send to backend (replace URL with your API)
    this.http.post(this.saveUrl, payload).subscribe({
      next: (res: any) => {
        console.log('Save success', res);
        alert('Shifts saved successfully!');
      },
      error: (err: any) => {
        console.error('Save failed', err);
        alert('Error: ' + (err.error?.message || 'Failed to save shifts'));
      },
    });
  }
}
