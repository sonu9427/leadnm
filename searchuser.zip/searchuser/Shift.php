<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Shift extends Model
{
    protected $fillable = [
        'shift_name',
        'code',
    ];

    public function days(): HasMany
    {
        return $this->hasMany(ShiftDay::class);
    }
}
