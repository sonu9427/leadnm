<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserOrganization extends Model
{
    use HasFactory;
    protected $table = 'user_organization';
    protected $fillable = [
        'user_id ',
        'first_name',
        'last_name',
        'date_hired',     
    ];

    /**
     * Get the user that owns the UserOrganization
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
