<?php

namespace App\Models;

use App\Http\Controllers\API\StudentController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    use HasFactory;
    protected $guarded;
    public $timestamps = false;

    public function stud()
    {
        return $this->belongsTo(Stud::class,'student_id','id');
    }
}
