<?php

use Illuminate\Support\Facades\Route;

use App\Jobs\SendEmailJob;
use Illuminate\Http\Request;
use App\Http\Controllers\EmailController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('email_form');
})->name('email.form');


Route::post('send-mail', function (Request $request) {
    $data = $request->only(['email', 'subject', 'message']);
    $emails = explode(',', $data['email']);
    foreach ($emails as $email) {
        $emailData = [
            'email' => trim($email),
            'subject' => $data['subject'],
            'message' => $data['message']

        ];

        dispatch(new SendEmailJob($emailData));
    }

    return back()->with('success', 'Email Sent Successfully');
})->name('send.mail');


Route::get('send-email',[EmailController::class,'sendEmail']);
