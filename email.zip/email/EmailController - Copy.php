<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;
use App\Models\User;

class EmailController extends Controller
{
    public function sendEmail()
    {
        $toEmail = "sunil.fcr@gmail.com";
        $message = "Hello, Welcome to our Website"; // Plain text message
        $subject = "Welcome to My Site";

        $fromEmail = User::find(1)->email;  // Fetching the email from User model

        // Send the email
      //  Mail::to($toEmail)->send(new WelcomeEmail($message, $subject));

      Mail::to($toEmail)
      ->from($fromEmail) // Dynamically set the 'from' email
      ->send(new WelcomeEmail($message, $subject));
        
        dd('Email sent successfully!');
    }
}
