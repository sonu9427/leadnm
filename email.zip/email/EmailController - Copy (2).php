<?php

namespace App\Http\Controllers;

use App\Mail\WelcomeEmail;
use Illuminate\Support\Facades\Mail;
use App\Models\User;

class EmailController extends Controller
{
    public function sendEmail()
    {
        // Fetch the user from the database (using User ID 1 as an example)
        $user = User::find(1);  // Example: Fetch the user with ID 1

        if (!$user) {
            return dd('User not found!');
        }

        // Get dynamic email credentials from the database (or elsewhere)
        $fromEmail = $user->email;  // Example: Fetch 'email' from 'users' table
        $smtpUsername = $user->email;  // Use email as the SMTP username (for Gmail, etc.)
        $smtpPassword = 'your-database-stored-password';  // Fetch this from the database or elsewhere

        // Set up custom SMTP settings dynamically for this mail send operation
        $mailer = Mail::mailer('smtp')->alwaysFrom($fromEmail)->getSwiftMailer();
        $transport = $mailer->getTransport();
        
        // Now, dynamically configure the SMTP credentials
        $transport->setUsername($smtpUsername);
        $transport->setPassword($smtpPassword);
        $transport->setHost('smtp.gmail.com');
        $transport->setPort(587);
        $transport->setEncryption('tls');

        // Define email details
        $toEmail = "sunil.fcr@gmail.com";  // The recipient email
        $message = "Hello, Welcome to our Website";
        $subject = "Welcome to My Site";

        // Send the email using the custom mailer
        Mail::to($toEmail)
            ->send(new WelcomeEmail($message, $subject, $fromEmail));

        dd('Email sent successfully!');
    }
}
