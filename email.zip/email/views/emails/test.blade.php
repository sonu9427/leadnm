<!DOCTYPE html>
<html>
<head>
    <title>Email Testing</title>
</head>
<body>
    <p>Hello,</p>
    {{-- <p>{{ $data['message'] }}</p> --}}
    <strong>Thanks!</strong>
</body>
</html>
